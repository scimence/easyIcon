﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SciUpdate
{
    // 示例：scimence( Name1(6JSO-F2CM-4LQJ-JN8P) )scimence
    // string url = Decodex104(0);
    // 
    // string data = getWebData(url);
    // string str1 = getNodeData(data, Decodex104(1), false);
    // string str2 = getNodeData(str1, Decodex104(2), true);

    /// <summary>
    /// 此类用于获取，在网络文件中的配置信息
    /// </summary>
    public class WebTool
    {
        private static string StringDatas106 = "gihehehahddkcpcpghgjhecogphdgdgigjgogbcogogfhecphdgdgjgngfgogdgfcpgfgbhdhjejgdgpgocphhgjglgjhdcpepgogmgjgogffdgfhcgjgbgm$hdgdgjgngfgogdgf$eogbgngfdb$hfhcgm$$gegbhegb$gogpgegfeogbgngf$gggjgogbgmeogpgegf$ci$cj";
        private static string[] StringDatas106A = null;
        
        private static string odearw104(int index107)
        {
            if (StringDatas106A == null) StringDatas106A = StringDatas106.Split((char)(',' - 8));    // '$'
            string data = StringDatas106A[index107];
            data = coderar.DecodeAlphabet(data);
            return data;
        }


        #region 网络数据的读取

        /// <summary>
        /// 获取url页面，key(**value**)中的value数据
        /// </summary>
        public static string getWebData(string url, string key)
        {
            string data = getWebData(url);
            string str1 = getNodeData(data, key, true);

            return str1;
        }

        /// <summary>
        /// 从给定的网址中获取数据
        /// </summary>
        /// <param name=Decodex104(3)></param>
        /// <returns></returns>
        public static string getWebData(string url)
        {
            try
            {
                System.Net.WebClient client = new System.Net.WebClient();
                client.Encoding = System.Text.Encoding.Default;
                string data = client.DownloadString(url);
                return data;
            }
            catch (Exception) { return odearw104(4); }
        }

        #endregion


        //p>scimence(&#x000A;NeedToRegister(false)NeedToRegister&#x000A;RegisterPrice(1)RegisterPrice&#x000A;)scimence</p>&#x000A;</div>
        /// <summary>
        /// 从自定义格式的数据data中，获取nodeName对应的节点数据
        /// 
        /// NeedToRegister(false)NeedToRegister     // finalNode = false;
        /// RegisterPrice(1)                        // finalNode = true;
        /// </summary>
        /// <param name=Decodex104(5)>待解析的数据</param>
        /// <param name=Decodex104(6)>节点名称</param>
        /// <param name=Decodex104(7)>是否为叶节点</param>
        /// <returns></returns>
        public static string getNodeData(string data, string nodeName, bool finalNode)
        {
            if (!data.Contains(nodeName)) return odearw104(4);

            try
            {
                string S = nodeName + odearw104(8), E = odearw104(9) + (finalNode ? odearw104(4) : nodeName);
                int indexS = data.IndexOf(S) + S.Length;
                int indexE = data.IndexOf(E, indexS);

                return data.Substring(indexS, indexE - indexS);
            }
            catch (Exception) { return data; }
        }
    }

}
