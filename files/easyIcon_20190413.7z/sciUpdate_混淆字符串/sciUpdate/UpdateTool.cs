﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SciUpdate
{
    public class coderar
    {
        /// <summary> 
        /// 解析字母字符串
        /// </summary>
        public static string DecodeAlphabet(string data)
        {
            byte[] B = new byte[data.Length / 2];
            char[] C = data.ToCharArray();
            for (int i = 0; i < C.Length; i += 2)
            {
                byte b = ToByte(C[i], C[i + 1]);
                B[i / 2] = b;
            }
            return System.Text.Encoding.UTF8.GetString(B);
        }
        
        /// <summary>  
        /// 每两个字母还原为一个字节
        /// </summary>
        private static byte ToByte(char a1, char a2)
        {
            return (byte)((a1 - 'a') * 16 + (a2 - 'a'));
        }
    }
        


    /// <summary>
    /// SciTools.UpdateTool.AutoUpdate();            // 应用自动检测更新；
    /// 
    /// 更新原理：
    /// 根据ToolUrl_MD5获取当前应用线上的md5信息，
    /// 通过Update.exe判断当前应用的MD5值与线上的md5信息是否相同，
    /// 若不同，则结束当前进程，从ToolUrl_MD5中解析当前应用网络路径，下载并启动。Update.exe自删除。
    /// 
    /// 依赖工具类:
    /// SciTools.WebTool.cs;                https://gitee.com/scimence/sciTools/raw/master/CS/WebTool.cs
    /// SciTools.EncoderTool_Alphabet.cs;   https://gitee.com/scimence/sciTools/raw/master/CS/EncoderTool_Alphabet.cs 
    /// </summary>
    public class UpdateTool
    {
        private static string StringDatas103 = "hdgdgjgngfgogdgf$edgigbgogogfgmeegfgngpfegpgpgm$$fm$fmfm$cc$cofahcgphagfhchegjgfhdcofcgfhdgphfhcgdgfhd$eddkfmffhdgfhchdfmhhgbgoghhkgigpgoghhjhfgbgofmeegpgdhfgngfgohehdfmalgjhdhfgbgmcahdhehfgegjgpcadcdadbdcfmfahcgpgkgfgdhehdfmehgjggfegpgpgmfmehgjggfegpgpgmfmfcgfhdgphfhcgdgfhdfmffhagegbhegfcogegbhegb$cfhogehadaffhagegbhegfcogfhigf$fledepeoegejehfngihehehahddkcpcpghgjhecogphdgdgigjgogbcogogfhecpgkgphjgngfgoghcpgdgigbgogogfgmeegfgngpcphcgbhhcpgngbhdhegfhccpeneedfcohehihe$efdkajgnhadcffhagegbhegffpeggjgmgfhdfm$oglikaojibjdoikokboileljofimifaadadadadadadbfm$ffhagegbhegfcogfhigf$ffhagegbhegf$fledepeoegejehfn$ca$fceffdfeebfcfe$fegpgpgmffhcgmfpeneedf$hagfhcgggjhifpeffief$gihehehahddkcpcp$coghgjhegfgfcogjgpcp$cpeneedfcohehihe$gihehehahddkcpcpghgjhecogphdgdgigjgogbcogogfhecp$cp$cphcgbhhcpgngbhdhegfhccpeneedfcohehihe$cogfhigf$gdgpgogggjghffhcgm$glgfhj$cpgdgpgogggjghcohehihe$cphcgbhhcpgngbhdhegfhccpgdgpgogggjghcohehihe$gfhihagmgphcgfhccogfhigf$cpgfcmca";
        private static string[] StringDatas103A = null;
        
        private static string codexx101(int index104)
        {
            if (StringDatas103A == null) StringDatas103A = StringDatas103.Split((char)(',' - 8));    // '$'
            string data = StringDatas103A[index104];
            data = coderar.DecodeAlphabet(data);
            return data;
        }


        // 当前命名空间名称
        public static string SoftName = GetNamespace(Assembly.GetEntryAssembly());
        public static string AuthorName = codexx101(0);

        //private static string NAMESPACE = Decodex101(1);

        /// <summary>
        /// 获取Assembly所在的命名空间名称
        /// </summary>
        public static string GetNamespace(Assembly asssembly)
        {
            string Namespace = codexx101(2);
            Type[] types = asssembly.GetTypes();
            if (types != null && types.Length > 0)
            {
                Namespace = types[0].Namespace;
            }
            return Namespace;
        }

        /// <summary>
        /// 获取当前运行路径
        /// </summary>
        public static string curDir()
        {
            return AppDomain.CurrentDomain.BaseDirectory;
        }

        /// <summary>
        /// 检测目录是否存在，若不存在则创建
        /// </summary>
        public static void checkDir(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        /// <summary>
        /// 保存Byte数组为文件
        /// </summary>
        public static void SaveFile(Byte[] array, string path, bool repalce = false)
        {
            if (repalce && System.IO.File.Exists(path)) System.IO.File.Delete(path);    // 若目标文件存在，则替换
            if (!System.IO.File.Exists(path))
            {
                // 创建输出流
                System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

                //将byte数组写入文件中
                fs.Write(array, 0, array.Length);
                fs.Close();
            }
        }

        /// <summary>
        /// 为arg添加引号
        /// </summary>
        public static string AddQuotation(string arg)
        {
            if (arg.EndsWith("\\") && !arg.EndsWith("\\\\")) arg += "\\";
            arg = "\"" + arg + "\"";

            return arg;
        }

        /// <summary>
        /// 获取Resource资源
        /// </summary>
        public static byte[] getResource(string name)
        {
            string Namespace = Assembly.GetEntryAssembly().GetTypes()[0].Namespace;
            System.Resources.ResourceManager rm = new System.Resources.ResourceManager(Namespace + codexx101(6), System.Reflection.Assembly.GetExecutingAssembly());
            byte[] bytes = (byte[])rm.GetObject(name);

            return bytes;
        }

        /// <summary>
        /// 获取Updata.exe文件内容
        /// </summary>
        private static byte[] getUpdataData()
        {
            //string file = Decodex101(7);
            //string data = Encoder.getFileData(file);

            byte[] bytes = EncoderTool_Alphabet.ToBytes(data);
            return bytes;
        }

        // Decodex101(8) Decodex101(9) Decodex101(10) Decodex101(11)
        /// <summary>
        /// 调用Update.exe，更新以perfix为前缀的配置文件
        /// </summary>
        public static void updateFiles(string url, string perfix, bool RESTART = false)
        {
            string update_EXE = curDir() + codexx101(12);

            //byte[] bytes = getResource(Decodex101(13));
            byte[] bytes = getUpdataData();

            if (!File.Exists(update_EXE)) SaveFile(bytes, update_EXE, false);
            else if (!updateIsRunning()) SaveFile(bytes, update_EXE, true);   // 更新Update.exe

            string path = curDir();
            url = AddQuotation(codexx101(14) + url);
            path = AddQuotation(path);
            perfix = AddQuotation(perfix);
            update_EXE = AddQuotation(update_EXE);

            // 调用更新插件执行软件更新逻辑
            String arg = url + codexx101(15) + path + codexx101(15) + perfix;
            if (RESTART) arg += codexx101(15) + codexx101(16);
            System.Diagnostics.Process.Start(update_EXE, arg);

            autoDeletUpdateExe();   // 更新后删除update.exe
        }

        private static Timer timer = null;
        private static void autoDeletUpdateExe(object sender = null, EventArgs e = null)
        {
            string update_EXE = curDir() + codexx101(12);
            if (!File.Exists(update_EXE)) return;

            if (!updateIsRunning())
            {
                File.Delete(update_EXE);

                if (timer != null)
                {
                    timer.Stop();
                    timer = null;
                }
            }
            else
            {
                if (timer == null)
                {
                    timer = new Timer();
                    timer.Interval = 700;
                    timer.Tick += new System.EventHandler(autoDeletUpdateExe);
                    timer.Start();
                }
            }
        }

        /// <summary>
        /// 应用自更新,也可更新MD5.txt中配置的任意文件
        /// </summary>
        /// <param name=Decodex101(17)>工具MD5信息文件的url地址</param>
        /// <param name=Decodex101(18)>当前待更新的应用名称</param>
        public static void AutoUpdate(string ToolUrl_MD5 = "", string perfix_EXE = "")
        {
            //if (ToolUrl_MD5.Equals(Decodex101(2))) ToolUrl_MD5 = Decodex101(19) + AuthorName + Decodex101(20) + SoftName + Decodex101(21);
            if (ToolUrl_MD5.Equals(codexx101(2))) ToolUrl_MD5 = codexx101(22) + AuthorName + codexx101(23) + SoftName + codexx101(24);
            if (perfix_EXE.Equals(codexx101(2))) perfix_EXE = SoftName + codexx101(25);

            updateFiles(ToolUrl_MD5, perfix_EXE, true);
        }

        /// <summary>
        /// 获取指定网址中的配置信息
        /// </summary>
        /// <param name=Decodex101(26)>配置信息对应网址</param>
        /// <param name=Decodex101(27)>配置节点名</param>
        public static String GetWebConfig(string key = "", string configUrl = "")
        {

            //if (configUrl.Equals(Decodex101(2))) configUrl = Decodex101(19) + AuthorName + Decodex101(20) + SoftName + Decodex101(28);
            if (configUrl.Equals(codexx101(2))) configUrl = codexx101(22) + AuthorName + codexx101(23) + SoftName + codexx101(29);
            if (key.Equals(codexx101(2))) return codexx101(2);

            return WebTool.getWebData(configUrl, key);
        }

        /// <summary>
        /// 打开本地路径
        /// </summary>
        public static void openChannelDir(string channelDir)
        {
            string localDir = curDir() + channelDir.Replace("/", "\\");
            checkDir(localDir);

            if (Directory.Exists(localDir))
            {
                System.Diagnostics.Process.Start(codexx101(30), codexx101(31) + localDir);
            }
        }

        // 判断当前是有更新任务正在执行
        public static bool updateIsRunning()
        {
            // 获取Update.exe后台进程
            System.Diagnostics.Process[] processes1 = System.Diagnostics.Process.GetProcessesByName(codexx101(13));

            // 无更新进程Update.exe，表示更新完成
            return (processes1 != null && processes1.Length != 0);
        }

        // Update.exe文件
        private static string data = "enfkjaaaadaaaaaaaeaaaaaappppaaaaliaaaaaaaaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiaaaaaaaaobplkaoaaleajmncbliabemmncbfegigjhdcahahcgpghhcgbgncagdgbgogogphecagcgfcahchfgocagjgocaeeepfdcagngpgegfcoananakceaaaaaaaaaaaaaafaefaaaaemabadaajegijffjaaaaaaaaaaaaaaaaoaaaacabalabalaaaadiaaaaaaaiaaaaaaaaaaaahofgaaaaaacaaaaaaagaaaaaaaaaeaaaaacaaaaaaaacaaaaaeaaaaaaaaaaaaaaaeaaaaaaaaaaaaaaaakaaaaaaaacaaaaaaaaaaaaacaaeaifaaaabaaaaabaaaaaaaaabaaaaabaaaaaaaaaaaaabaaaaaaaaaaaaaaaaaaaaaaacmfgaaaaepaaaaaaaagaaaaakaafaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaiaaaaaamaaaaaapefeaaaabmaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaacaaaaaaiaaaaaaaaaaaaaaaaaaaaaaaicaaaaaeiaaaaaaaaaaaaaaaaaaaaaacohegfhiheaaaaaaiedgaaaaaacaaaaaaadiaaaaaaacaaaaaaaaaaaaaaaaaaaaaaaaaaaacaaaaagacohchdhcgdaaaaaakaafaaaaaagaaaaaaaagaaaaaadkaaaaaaaaaaaaaaaaaaaaaaaaaaaaeaaaaaeacohcgfgmgpgdaaaaamaaaaaaaaiaaaaaaaacaaaaaaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeaaaaaecaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaagafgaaaaaaaaaaaaeiaaaaaaacaaafaakidkaaaaembkaaaaabaaaaaabnaaaaagpadjaaaaliaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabddaacaacmaaaaaaabaaaabbaahcabaaaahaakaccibbaaaaakbgpoabanajcnbcaaacciacaaaaagalahbpcacibdaaaaagakaaagamclaaaickbddaacaadnaaaaaaacaaaabbaahcabaaaahaakaccibbaaaaakbgpoabanajcncdaaaccibcaaaaakhdbdaaaaakalahgpbeaaaaakakahgpbfaaaaakaaahgpbgaaaaakaaaaagamclaaaickaaaaaabddaafaamiaaaaaaadaaaabbaabggkakadbggkpoabbgpoabamaicnakaaacakagaldikmaaaaaaaaadbpbpgkpoabbgpoabamaicncfaaacbhgkfpcibhaaaaakbgpoabamaicnalaacaaaaaaaiagoakaaclafaabggkakaaagalclhjaaadbggkdcaladbpbpgkpoacbgpoabclabbgaaamaicnacaaaaaaaaachoafaaaaaebpbpgkadfjnejgfpcibhaaaaakbgpoabamaicncgaaachoaeaaaaaebpbpgkadbhgkfifjnejgfphoafaaaaaeadnejgfkcaaaaaaaiagogaakaaclbkaaachoaeaaaaaebpbpgkadfjnejgfphoafaaaaaeadnejgfkakaaagalclaaahckbddaafaaklaaaaaaadaaaabbaabggkakadbggkpoabbgpoabamaicnakaaacakagaldiipaaaaaaaaadbpbpgkpoabbgpoabamaicncfaaaccaaaaaaaiagofpcibhaaaaakbgpoabamaicnahaabhgkakaaclafaabggkakaaagalclfmaaadbggkdcaladbpbpgkpoacbgpoabclabbgaaamaicnacaaaaaaaaaccapopppphpgkfphoafaaaaaeadnejgflakaccaaaaaaaiagofpcibhaaaaakbgpoabamaicnbhaaagcaaaaaaaeagkhoafaaaaaeadbhgkfjnejgflgaakaaagalclaaahckaabddaaeaaboaaaaaaaeaaaabbaabggkakacadciadaaaaagacbpcagkadfjciaeaaaaaggaakagalclaaahckaaaabddaadaankaaaaaaafaaaabbaabggkakbggkalbggkambggkanbggkbdaebggkbdafaccaaaaaaaiagofpanadcaaaaaaaiagofpbdaeaccaaaaaaaeagkfpaladcaaaaaaaeagkfpamaccappppppdpgkfpadcappppppdpgkfpfibdafahaifpcibhaaaaakbgpoabbdahbbahcnbeaabbafcaaaaaaaiagogbajgbbbaegbbdafaaclfnahaigacibhaaaaakbgpoabbdahbbahcnebaabbafcaaaaaaaeagkfpcibhaaaaakbgpoabbdahbbahcnbeaabbafcaaaaaaamagogbajgbbbaegbbdafaaclbcaabbafcaaaaaaaeagkgbajgbbbaegbbdafaaaaclalaabbafajgbbbaegbbdafaabbafakagbdagclaabbagckaaaabddaadaabdaaaaaaaeaaaabbaabggkakacadfpacggaefpgaakagalclaaahckaabddaadaabdaaaaaaaeaaaabbaabggkakacaefpadaeggfpgaakagalclaaahckaabddaacaabaaaaaaaaeaaaabbaabggkakacadgbaegbakagalclaaahckbddaadaabbaaaaaaaeaaaabbaabggkakadacaegggagbakagalclaaahcknkaaacacemadaeafciahaaaaagaoaeciagaaaaagaoagciagaaaaagciagaaaaagffacacemaoafciafaaaaagffacacemadciagaaaaagffcknkaaacacemadaeafciaiaaaaagaoaeciagaaaaagaoagciagaaaaagciagaaaaagffacacemaoafciafaaaaagffacacemadciagaaaaagffcknkaaacacemadaeafciajaaaaagaoaeciagaaaaagaoagciagaaaaagciagaaaaagffacacemaoafciafaaaaagffacacemadciagaaaaagffcknkaaacacemadaeafciakaaaaagaoaeciagaaaaagaoagciagaaaaagciagaaaaagffacacemaoafciafaaaaagffacacemadciagaaaaagffckaaaaaabddaafaamdaaaaaaagaaaabbaabeakbgalbgambeanbgbdaebgbdafbgbdagcibcaaaaakacgpbiaaaaakbdahbbahiogjalahbofibpeaflbhfibpbafkamaiinblaaaaabanbgbdaebgbdafclcnaabbafbkflbdagbbafbkfnbofkbdaeajbbagajbbagjgbbahbbafjbgobbaegkciadaaaaaggajpbbafbhfibdafaabbafahpoaebdajbbajcnmibbafbkflbdagbbafbkfnbofkbdaeajbbagajbbagjgcaiaaaaaaagkbbaegkciadaaaaaggajpajaibifjahgkbjgkciadaaaaagjpajaibhfjahgkbpbngkciaeaaaaagjpajakagbdaiclaabbaickaabddaaeaahnaaaaaaaiaaaabbaahcabaaaahaakbggkalbgambganbgamclfgaaacaibofkgkciaeaaaaaghoaeaaaaaebnjgfpalhcadaaaahaahcibbaaaaagcibjaaaaakgpbkaaaaakbifjanaghcadaaaahaahcibbaaaaagcibjaaaaakajbgdcadajclabbgaagpblaaaaakcibjaaaaakakaaaibhfiamaibjpoacbgpoabbdafbbafcnjnagbdaeclaabbaeckaaaaaabddaacaadcaaaaaaajaaaabbaahcabaaaahaakclbkaaacbpbagkfncibcaaaaagagcibjaaaaakakacbpbagkflbaaaaaacbggkpoacamaicnnnagalclaaahckaaaabddaacaahkaaaaaaakaaaabbaahcabaaaahaakacamaibpapgkdacjaibpakgkdcffaibpakgkfjgjefagaaaaaaacaaaaaaakaaaaaabcaaaaaabkaaaaaaccaaaaaackaaaaaacldahcahaaaahaakcldchcalaaaahaakclckhcapaaaahaakclcchcbdaaaahaakclbkhcbhaaaahaakclbchcblaaaahaakclakapaacibmaaaaakakclaaagalclaaahckaaaabddaahaaghaiaaaaalaaaabbaahcabaaaahaakbgalclekaahoaeaaaaaeahcdaaaaaaaaaaaaaaeaahbhfigmcibnaaaaakcdaaaaaaaaaaaapadpfjciboaaaaakjphoafaaaaaeahcdaaaaaaaaaaaaaaeaahgmcibnaaaaakciboaaaaakjpaaahbhfialahbpbopoacbgpoabbdanbbancnkibeambganbggkbdaebggkbdafbggkbdagbggkbdahbggkbdaibggkbdajbggkbdakbggkbdalacciapaaaaagamcaabcdefghgkbdaicaijklmnopgobdajcaponmlkjigobdakcahgfedcbagkbdalbgandiehahaaaaaabbaibdaebbajbdafbbakbdagbbalbdahbcaibbajbbakbbalaiajjgbngkcahikegknhgocialaaaaagaabcalbbaibbajbbakaiajbhfijgbpamgkcafglhmhoigocialaaaaagaabcakbbalbbaibbajaiajbifijgbpbbgkcanlhacacegkcialaaaaagaabcajbbakbbalbbaiaiajbjfijgbpbggkcaoomolnmbgocialaaaaagaabcaibbajbbakbbalaiajbkfijgbngkcakpaphmpfgocialaaaaagaabcalbbaibbajbbakaiajblfijgbpamgkcackmgihehgkcialaaaaagaabcakbbalbbaibbajaiajbmfijgbpbbgkcabdegdakigocialaaaaagaabcajbbakbbalbbaiaiajbnfijgbpbggkcaabjfegpngocialaaaaagaabcaibbajbbakbbalaiajbofijgbngkcanijiiagjgkcialaaaaagaabcalbbaibbajbbakaiajbpajfijgbpamgkcakppheeilgocialaaaaagaabcakbbalbbaibbajaiajbpakfijgbpbbgkcalbflppppgocialaaaaagaabcajbbakbbalbbaiaiajbpalfijgbpbggkcalonhfmijgocialaaaaagaabcaibbajbbakbbalaiajbpamfijgbngkcaccbbjaglgkcialaaaaagaabcalbbaibbajbbakaiajbpanfijgbpamgkcajdhbjipngocialaaaaagaabcakbbalbbaibbajaiajbpaofijgbpbbgkcaioedhjkggocialaaaaagaabcajbbakbbalbbaiaiajbpapfijgbpbggkcacbaileejgkcialaaaaagaabcaibbajbbakbbalaiajbhfijgblgkcagccfbopggociamaaaaagaabcalbbaibbajbbakaiajbmfijgbpajgkcaealdeamagociamaaaaagaabcakbbalbbaibbajaiajbpalfijgbpaogkcafbfkfocggkciamaaaaagaabcajbbakbbalbbaiaiajjgbpbegkcakkmhlgojgociamaaaaagaabcaibbajbbakbbalaiajblfijgblgkcafnbacpnggociamaaaaagaabcalbbaibbajbbakaiajbpakfijgbpajgkcafdbeeeacgkciamaaaaagaabcakbbalbbaibbajaiajbpapfijgbpaogkcaibogkbnigociamaaaaagaabcajbbakbbalbbaiaiajbkfijgbpbegkcamiplndohgociamaaaaagaabcaibbajbbakbbalaiajbpajfijgblgkcaogmnobcbgkciamaaaaagaabcalbbaibbajbbakaiajbpaofijgbpajgkcangahdhmdgociamaaaaagaabcakbbalbbaibbajaiajbjfijgbpaogkcaihannfpegociamaaaaagaabcajbbakbbalbbaiaiajbofijgbpbegkcaonbefkefgkciamaaaaagaabcaibbajbbakbbalaiajbpanfijgblgkcaafojodkjgociamaaaaagaabcalbbaibbajbbakaiajbifijgbpajgkcapikdoppmgociamaaaaagaabcakbbalbbaibbajaiajbnfijgbpaogkcanjacgpghgkciamaaaaagaabcajbbakbbalbbaiaiajbpamfijgbpbegkcaikemckingociamaaaaagaabcaibbajbbakbbalaiajblfijgbkgkcaecdjpkppgocianaaaaagaabcalbbaibbajbbakaiajbofijgbpalgkcaibpghbihgocianaaaaagaabcakbbalbbaibbajaiajbpalfijgbpbagkcaccgbjngngkcianaaaaagaabcajbbakbbalbbaiaiajbpaofijgbpbhgkcaamdiofpngocianaaaaagaabcaibbajbbakbbalaiajbhfijgbkgkcaeeoklokegocianaaaaagaabcalbbaibbajbbakaiajbkfijgbpalgkcakjmpnoelgkcianaaaaagaabcakbbalbbaibbajaiajbnfijgbpbagkcagaelllpggocianaaaaagaabcajbbakbbalbbaiaiajbpakfijgbpbhgkcahalmlplogocianaaaaagaabcaibbajbbakbbalaiajbpanfijgbkgkcamghojlcigkcianaaaaagaabcalbbaibbajbbakaiajjgbpalgkcapkchkbokgocianaaaaagaabcakbbalbbaibbajaiajbjfijgbpbagkcaifdaopnegocianaaaaagaabcajbbakbbalbbaiaiajbmfijgbpbhgkcaafbniiaegkcianaaaaagaabcaibbajbbakbbalaiajbpajfijgbkgkcadjnanenjgocianaaaaagaabcalbbaibbajbbakaiajbpamfijgbpalgkcaofjjnloggocianaaaaagaabcakbbalbbaibbajaiajbpapfijgbpbagkcapihmkcbpgkcianaaaaagaabcajbbakbbalbbaiaiajbifijgbpbhgkcagffgkmmegocianaaaaagaabcaibbajbbakbbalaiajjgbmgkcaeecccjpegociaoaaaaagaabcalbbaibbajbbakaiajbnfijgbpakgkcajhppckedgkciaoaaaaagaabcakbbalbbaibbajaiajbpaofijgbpapgkcakhcdjeklgociaoaaaaagaabcajbbakbbalbbaiaiajblfijgbpbfgkcadjkajdpmgociaoaaaaagaabcaibbajbbakbbalaiajbpamfijgbmgkcamdfjflgfgkciaoaaaaagaabcalbbaibbajbbakaiajbjfijgbpakgkcajcmmamipgociaoaaaaagaabcakbbalbbaibbajaiajbpakfijgbpapgkcahnpeopppgociaoaaaaagaabcajbbakbbalbbaiaiajbhfijgbpbfgkcanbfnieifgociaoaaaaagaabcaibbajbbakbbalaiajbofijgbmgkcaephokigpgkciaoaaaaagaabcalbbaibbajbbakaiajbpapfijgbpakgkcaoaogcmpogociaoaaaaagaabcakbbalbbaibbajaiajbmfijgbpapgkcabeedabkdgociaoaaaaagaabcajbbakbbalbbaiaiajbpanfijgbpbfgkcakbbbaieogkciaoaaaaagaabcaibbajbbakbbalaiajbkfijgbmgkcaichofdphgociaoaaaaagaabcalbbaibbajbbakaiajbpalfijgbpakgkcadfpcdklngociaoaaaaagaabcakbbalbbaibbajaiajbifijgbpapgkcallncnhckgkciaoaaaaagaabcajbbakbbalbbaiaiajbpajfijgbpbfgkcajbndigolgociaoaaaaagaabbaibbaeciagaaaaagbdaibbajbbafciagaaaaagbdajbbakbbagciagaaaaagbdakbbalbbahciagaaaaagbdalaaajbpbafianajaiiogjpoaebdanbbandkkkpippppadbpcapoabbgpoabbdanbbancnclaabbaicibaaaaaagbbajcibaaaaaagbbakcibaaaaaagbbalcibaaaaaagcibpaaaaakgpcaaaaaakakaaclblaabbajcibaaaaaagbbakcibaaaaaagcibjaaaaakgpcaaaaaakakaaagbdamclaabbamckggbpbpinblaaaaabiaaeaaaaaebpbpinblaaaaabiaafaaaaaeckboaccicbaaaaakckaaaaaabddaabaaapaaaaaaamaaaabbaahcbpaaaahaakagcibiaaaaagaackaabddaacaadfaaaaaaanaaaabbaaaccibbaaaaakcmbfacgpcaaaaaakhcdpaaaahagpccaaaaakbgpoabclabbhaaalahcnbaaaaccicdaaaaakakagcibiaaaaagaaaackaaaaaabldaacaadmaaaaaaaoaaaabbaaacciceaaaaakakaaaganbgbdaeclboajbbaejkalaaaaahgpcfaaaaakaaaanoafamaaaanoaaaaaabbaebhfibdaebbaeajiogjpoaebdafbbafcnnfckabbaaaaaaaaabgaaalcbaaafcaaaaaabbddaacaacpaaaaaaapaaaabbaacicgaaaaakalbcabaccichaaaaakalbcabciciaaaaakakclaacicgaaaaakalbcabciciaaaaakagpoaeamaicnomckaabddaacaacpaaaaaabaaaaabbaaaccibbaaaaakbgpoabamaicnaiaccicdaaaaakbaaaacciceaaaaakakagcmaiagiogjbgpoacclabbgaaalclaaahckboaccicbaaaaakckaabddaacaagnaaaaaabbaaaabbaahdcjaaaaakakaccmalaciogjbgpoacbgpoabclabbhaaanajcnehaaaaacbdaebgbdafcldabbaebbafjkalaaahhcejaaaahagpckaaaaakbgpoabanajcnaibhiaagaaaaaeclaiagahgpclaaaaakaaaabbafbhfibdafbbafbbaeiogjpoaeanajcnmeaaaggpcmaaaaakamclaaaickaaaaaabddaafaabpabaaaabcaaaabbaaaccibmaaaaagbaaahcabaaaahaakhcabaaaahaalhcabaaaahaamhcabaaaahaanaciogjbgpoacbgpoabbdaebbaecnboacbgjkgpcoaaaaakbhinceaaaaabbdafbbafbgbpccjnbbafgpcpaaaaakakaciogjbhpoacbgpoabbdaebbaecnboacbhjkgpcoaaaaakbhinceaaaaabbdafbbafbgbpccjnbbafgpcpaaaaakalaciogjbipoacbgpoabbdaebbaecnboacbijkgpcoaaaaakbhinceaaaaabbdafbbafbgbpccjnbbafgpcpaaaaakamaciogjbjpoacbgpoabbdaebbaecnboacbjjkgpcoaaaaakbhinceaaaaabbdafbbafbgbpccjnbbafgpcpaaaaakanaghcfjaaaahagpdaaaaaakbgpoabbdaebbaecncmaaaghcfjaaaahagpbkaaaaakgpblaaaaakakagahaiajhcglaaaahagpckaaaaakbgpoabcicbaaaaagaaaaclajagahaiciboaaaaagaackaabldaadaadiabaaaabdaaaabbaaaaachcabaaaahagpckaaaaakanajdkbjabaaaaaaadhcabaaaahagpckaaaaakbgpoabanajcnbmcidbaaaaakgpdcaaaaakhchhaaaahaacciddaaaaakcideaaaaakbaabadcibbaaaaakbgpoabanajcnelaaadciabaaaaagakagaegpckaaaaakanajcndaaaadcibkaaaaagbgpoabanajcnbiaaadcibhaaaaagaacdaaaaaaaaaahakheacibjaaaaagaaaaadcidfaaaaakaaaaclafnnjoaaaaaaaaclahadcibpaaaaagaahddgaaaaakaladhcjdaaaahagpccaaaaakbgpoabanajcnefaaahacgpdhaaaaakamaihcjnaaaahagpdiaaaaakcmanaihckbaaaahagpdiaaaaakclabbhaaanajcnbbaihcjnaaaahahckbaaaahagpdjaaaaakamaiadcicaaaaaagcgaaclajahacadgpdkaaaaakaahoagaaaaaebgpoabanajcnbiaacdaaaaaaaaaaeajpeacibjaaaaagaaadcidlaaaaakcgaaaaaanoafcgaaaanoaaaaaackebbmaaaaaaaaaaaaabaaaaaacpabaaaadaabaaaaafaaaaaaabaaaaabbddaabaabkaaaaaaanaaaabbaaaccidmaaaaakakagcidnaaaaakalahcnahagcidoaaaaakcgckaaaabddaadaackaaaaaabeaaaabbaaadbgcidpaaaaakhdeaaaaaakakagacgpebaaaaakaaaggpecaaaaakaaaggpedaaaaakaaadalclaaahckaaaabldaaeaadgadaaaabfaaaabbaaachcabaaaahagpckaaaaakbgpoabbdapbbapcnafdibladaaaaadhcabaaaahagpckaaaaakbgpoabbdapbbapcnbgcidbaaaaakgpdcaaaaakhchhaaaahacibjaaaaakbaabhcabaaaahaakaehckhaaaahagpdiaaaaakbgpoabbdapbbapcnclaaaehckhaaaahagpeeaaaaakalaeahhckhaaaahagpbkaaaaakfigpblaaaaakakaebgahgpefaaaaakbaacaaacciceaaaaagamaihcabaaaahagpckaaaaakbgpoabbdapbbapcnafdiimacaaaaaihcknaaaahabhcicfaaaaaggpcoaaaaakanaihclnaaaahabgcicfaaaaaggpcoaaaaakbdaebbaehckbaaaahahcjnaaaahagpdjaaaaakbhinceaaaaabbdbabbbabgbpakjnbbbagpegaaaaakbdafhdcjaaaaakbdagaabbafbdbbbgbdbcdiepabaaaabbbbbbbcjkbdahaabbahgpcoaaaaakbhinceaaaaabbdbabbbabgbpcjjnbbbagpehaaaaakbdaibbaihcabaaaahagpckaaaaakbgpoabbdapbbapcnafdiajabaaaaaehcmjaaaahagpdiaaaaakbgpoabbdapbbapcnbcaehcmjaaaahahcmnaaaahagpdjaaaaakbaacaehcabaaaahagpckaaaaakcnakbbaiaegpdaaaaaakclabbhaabdapbbapcnafdilpaaaaaahcabaaaahabdajbbaihcnbaaaahagpdiaaaaakbgpoabbdapbbapcncgaabbaihcnbaaaahagpeiaaaaakalbbaiahbhfigpblaaaaakbdajbbaibgahgpefaaaaakbdaiaaadbbaihcmnaaaahahcmjaaaahagpdjaaaaakcibjaaaaakbdakaghcabaaaahagpckaaaaakbdapbbapcncaadbbaiaeaggpdjaaaaakhcmnaaaahahcmjaaaahagpdjaaaaakcibjaaaaakbdakajbbaicibjaaaaakbbakbbajciboaaaaagaaafcmalbbagbbakgpejaaaaakclabbhaabdapbbapcnakbbagbbakgpclaaaaakaaaabbbcbhfibdbcbbbcbbbbiogjpoaebdapbbapdkkapoppppafbgpoabbdapbbapdklhaaaaaaaaadaehcmnaaaahahcmjaaaahagpdjaaaaakcibjaaaaakbdalaghcabaaaahagpckaaaaakbdapbbapcnbiadaghcmnaaaahahcmjaaaahagpdjaaaaakcibjaaaaakbdalbbalciccaaaaagbdambbambhinceaaaaabbdbabbbabgbpdljnbbbagpegaaaaakbdanaabbanbdbbbgbdbccldkbbbbbbbcjkbdaoaaaabbagbbaogpejaaaaakbdapbbapcnbcaabbaocibhaaaaagaabbaocidfaaaaakaaaaaanoafcgaaaanoaaaaaabbbcbhfibdbcbbbcbbbbiogjpoaebdapbbapcnliaabgciekaaaaakaackaaaaabbaaaaaaaaaonaccfbcadafabaaaaabbddaadaaoeaaaaaabgaaaabbaahcabaaaahahdelaaaaakakaccidnaaaaakbgpoabbdahbbahdkljaaaaaaaaacciemaaaaakalaaahbdaibgbdajclcobbaibbajjkamagaggpenaaaaakcmahhcnfaaaahaclafhcabaaaahaaaaicibjaaaaakgpeoaaaaakcgbbajbhfibdajbbajbbaiiogjpoaebdahbbahcnmeacciepaaaaakanaaajbdaibgbdajclenbbaibbajjkbdaeaabbaeciccaaaaagbdafbbafhcabaaaahagpckaaaaakbdahbbahcncdagaggpenaaaaakcmahhcnfaaaahaclafhcabaaaahaaabbafcibjaaaaakgpeoaaaaakcgaabbajbhfibdajbbajbbaiiogjpoaebdahbbahcnkfaaaggpfaaaaaakbdagclaabbagckbobgiaagaaaaaeckbldaacaacnaaaaaabhaaaabbaaaahddgaaaaakakagcidpaaaaakgpfbaaaaakaaagacgpdhaaaaakalahamnoakcgaahcabaaaahaamnoaaaaaickaaaaaaabbaaaaaaaaaabaabpcaaaakcaaaaaabbldaaeaafgaaaaaabiaaaabbaaaaadhcnbaaaahacibjaaaaakakhcnjaaaahaaecnadadclafhcabaaaahaaacibjaaaaakalacaggpeeaaaaakaggpbkaaaaakfiamacahaigpfcaaaaakanacaiajaifjgpefaaaaakbdaenoahcgaaacbdaenoaaaabbaeckaaaaabbaaaaaaaaaabaaekelaaahcaaaaaabboaccicbaaaaakckckaccicbaaaaakaaaaaackaabddaacaadpaaaaaabjaaaabbaahoahaaaaaebecifgaaaaakbgpoabamaicnccaahcnnaaaahanaagaaaaaccifhaaaaakgpfiaaaaakhdfjaaaaakakagiaahaaaaaeaahoahaaaaaealclaaahckaabddaabaaalaaaaaabkaaaabbaahoaiaaaaaeakclaaagckccaaaciaaiaaaaaeckbddaabaaalaaaaaablaaaabbaahoajaaaaaeakclaaagckfghdcmaaaaagciflaaaaakheahaaaaaciaajaaaaaeckboaccifmaaaaakckaaaaaaaaaaaaaaleaaaaaamomkoploabaaaaaajbaaaaaagmfdhjhdhegfgncofcgfhdgphfhcgdgfhdcofcgfhdgphfhcgdgffcgfgbgegfhccmcagnhdgdgphcgmgjgccmcafggfhchdgjgpgodndecodacodacodacmcaedhfgmhehfhcgfdngogfhfhehcgbgmcmcafahfgcgmgjgdelgfhjfegpglgfgodngcdhdhgbdfgddfdgdbdjdddegfdadidjcdfdhjhdhegfgncofcgfhdgphfhcgdgfhdcofchfgohegjgngffcgfhdgphfhcgdgffdgfheacaaaaaaaaaaaaaaaaaaaaaafaebeefaebeefaleaaaaaaecfdekecabaaabaaaaaaaaaaamaaaaaahgdecodacodddadddbdjaaaaaaaaafaagmaaaaaabiakaaaacdhoaaaaieakaaaaaiakaaaacdfdhehcgjgoghhdaaaaaaaaimbeaaaabiabaaaacdfffdaakebfaaaabaaaaaaacdehffejeeaaaaaalebfaaaajiaeaaaacdecgmgpgcaaaaaaaaaaaaaaacaaaaabfhbnkcajajabaaaaaapkcfddaabgaaaaabaaaaaadfaaaaaaahaaaaaaajaaaaaacnaaaaaaeoaaaaaafmaaaaaaaiaaaaaabgaaaaaablaaaaaaacaaaaaaadaaaaaaaeaaaaaaabaaaaaaabaaaaaaacaaaaaaabaaaaaaaaaaakaaabaaaaaaaaaaagaahfaagoaaakaajbaahmaaagaaeiacdhacagaahjacgeacagaamjadkpadagaapeadocadagaaalaeocadagaaciaeocadagaaehaeocadagaagaaeocadagaahjaeocadagaajeaeocadagaakpaeocadagaaohaemiaeagaaplaemiaeagaaajafocadagaaccafocadagaafcafdpafelaaggafaaaaagaajfafhfafagaalfafhfafagaannafndafagaapfafojafagaapoafndafagaaalagndafagaacoaggoaaagaaejaggoaaagaaepaggoaaagaahlaggoaaagaakeagndafakaamfagdpafagaaofaggoaaagaaopaggoaaagaadfahbkahagaaepahgoaaagaaghahgoaaagaahhahgoaaakaamdahliahagaabbaindafagaablaindafagaaecaindafagaaepaindafagaaicaigoaaagaajdaiojafakaaofaimnaiagaapmaidpafagaabjajhfafagaaeeajgoaaagaaejajgoaaagaagnajocadakaajjajidajakaalcajidajakaamhajhmaaaaaaaaaaabaaaaaaaaaaabaaabaaabaabaaabfaabjaaafaaabaaabaaabaabaaacaaabjaaafaaagaabgaaiaabbaaacmaabjaaafaaagaabmaaaaaabaaadeaabjaaafaaahaaceaaaaaabaaaeaaaekaaafaaahaachaaaaabbaaafmaaekaaajaaajaaclaafbiakjaaakaafbialiaaakaafbiamiaaakaabbaaomaacbaabbaapgaacbaabbaamhabggaabbaafiacjcaabbaaifacjgaabbaamjacleaafacaaaaaaaaajgaanhaabmaaabaaiicaaaaaaaaajgaanpaabmaaacaanecaaaaaaaaajbaaaaabcfaaadaakicbaaaaaaaajbaaahabcfaaafaagaccaaaaaaaajbaaaoabcfaaahaaimccaaaaaaaajbaabjabcfaaajaahecdaaaaaaaajbaacfabclaaalaajecdaaaaaaaajbaaclabclaaaoaalecdaaaaaaaajbaadbabclaabbaanacdaaaaaaaajbaadhabclaabeaaoncdaaaaaaaajbaadnabdcaabhaaceceaaaaaaaajbaaeeabdcaaboaaflceaaaaaaaajbaaelabdcaacfaajcceaaaaaaaajbaafcabdcaacmaammceaaaaaaaajbaafjabdoaaddaajmcfaaaaaaaajbaagmabeeaadeaacicgaaaaaaaajbaahgabeeaadfaagicgaaaaaaaajbaahmabeeaadgaapacgaaaaaaaajgaaicabejaadhaahncpaaaaaaaaigbiikabepaadjaagdcpaaaaaaaajbbijeagfdaadjaaiicpaaaaaaaajgaajaabfdaadjaakecpaaaaaaaajgaajfabfhaadjaaoicpaaaaaaaajgaakeabfhaadkaaeadaaaaaaaaajgaalaabfmaadlaahmdaaaaaaaaajgaalgabgbaadmaalhdaaaaaaaaaigbiikabepaadnaamadaaaaaaaaajbaampabgjaadnaadmdbaaaaaaaajbaanlabhaaadoaagidcaaaaaaaajgaaoaabhgaadpaamiddaaaaaaaajbaaolabfhaaecaapaddaaaaaaaajgaapkabhnaaedaacideaaaaaaaajgaaadacidaaefaahmdhaaaaaaaajgaabeacbmaaejaagmdiaaaaaaaajbbijeagfdaaekaahediaaaaaaaajgaacaacbmaaekaamadiaaaaaaaajgaaclacilaaelaadedjaaaaaaaaigbiikabepaaeoaadmdjaaaaaaaaidbiikabepaaeoaaeidjaaaaaaaajdaijfacjkaaeoaajedjaaaaaaaajdaikjacjpaaeoaakldjaaaaaaaajdailfackeaaeoaaledjaaaaaaaajgainjacliaaepaaobdjaaaaaaaaigbiikabepaaepaamldjaaaaaaaajbbijeagfdaaepaaaaaaabaaonacaaaaabaaonacaaaaabaapgacaaaaacaapnacaaaaabaapgacaaaaacaapnacaaaaabaapgacaaaaacaapnacaaaaabaaaiadaaaaacaaaladaaaaabaaaoadaaaaacaabaadaaaaadaabcadaaaaabaaaoadaaaaacaabaadaaaaadaabcadaaaaabaaaoadaaaaacaabaadaaaaadaabcadaaaaabaaaoadaaaaacaabaadaaaaadaabcadaaaaabaabeadaaaaacaabgadaaaaadaabiadaaaaaeaabkadaaaaafaaaoadaaaaagaabmadaaaaahaaboadaaaaabaabeadaaaaacaabgadaaaaadaabiadaaaaaeaabkadaaaaafaaaoadaaaaagaabmadaaaaahaaboadaaaaabaabeadaaaaacaabgadaaaaadaabiadaaaaaeaabkadaaaaafaaaoadaaaaagaabmadaaaaahaaboadaaaaabaabeadaaaaacaabgadaaaaadaabiadaaaaaeaabkadaaaaafaaaoadaaaaagaabmadaaaaahaaboadaaaaabaacbadaaaaabaapgacaaaaabaackadaaaaabaacoadaaaaabaacbadaaaaacaadcadaaaaabaadiadaaaaabaaeaadaaaaabaaemadaaaaabaaeaadaaaaabaafjadaaaaabaafjadaaaaabaafoadbabaacaaonacbabaadaagcadaaaaabaaonacaaaaabaaggadaaaaacaaonacaaaaabaagladbabaacaahfadbabaadaahnadbabaaeaaieadaaaaabaajbadaaaaabaafoadaaaaabaaggadaaaaacaajgadaaaaadaajpadaaaaabaakjadcjaaikabmeaadbaaikabmeaadjaaikabmeaaebaaikabmeaaejaaikabmeaafbaaikabmeaafjaaikabmeaagbaaikabmeaagjaaikabmeaahbaaikabmjaahjaaikabmeaaibaaikabmeaaijaaikabmeaajbaaikabmoaakbaaikabneaakjaaikabepaalbaaocafgbaaljaanjacoaaambaaikabofaamjaabgagomaamjaacaagepaamjaacgagepaanbaadgagpiaaljaaeaagbdabobaafgaghnaaobaafnagckabobaagiagcoabnjaahcagomaaojaaiaageiabnbaaieageoabobaafgagfdabobaaimagomaaajaaikabepaaobaajlaghbabpbaakjagbmaapjaamnaghlabpjaaoaagepaaajabpiagjcabajabaaahjiabajabbaahjpabamaaikabepaaobaadmahhbabamaaedahlkabamaaehahmaabbjabikabepaaobaagcahomaaobaagcahnlabobaagmahhbabcjabibaholabcjabjdahomaapbaakfahbmaaobaafgagpbablbaalbahfhaadbabikabepaadbabmnahpiabobaanmahhbabobaaofahpnabdbabonahadacpjaapkahajacpbaaaaaibmaadjabocafgbaadjabcjaibiacljaadjaioaaaejabikabbpacfbabfkaimeaafbabcaagepaafbabcgagepaaobaagaaicoacobaagiagddacobaagiaidjacobaagoainlabobaahgaicoacamaanmaheaacfjabioaiegacgbabikabmeaadjabkbaigkacgbabfnagckabgbabkkaihaacdjablbaigkacajaahcagomaadbabmaaiijacobaagaaijhacgjabikabadachbabikabepaahjabikabepaaajaadeajogacibabflajomacibabhgajpfacbjaaikabplacjjabikabbaadkjabneajhpadbbaaikabepaaaiaaaeaaanaaaiaaaiaabcaaaiaaamaabhaaaoaaababaaaaaoaaafabaaaaaoaabjabaaaaaoaabnabaaaaacaacbabmcaacjaandacbhadcoaablaanmadcoaacdaapkadcoaaclaaaaaecoaaidaahhaecoaaedaapkadcoaahlaagoaecoaabdaanaadcoaaddaanaadcoaadlaaaoaecoaaalaaiiadcoaafdaapkadcoaaflaacoaecoaaglaafiaecoaahdaagfaeejaandacbhadmdaajlackfacmdaakdacngabmdaaklacngabodaajlaccaadodaaklacngabkaadglabngabnjaapaaapnaaadabaiabbjabakaaddabdmabecabflabgnabhgabicabkdabklabmgabobabapacchacelachhacipacjnacadadaladhkadagaaabaaahaaadaaaaaaeiackkaaaaaambackpaaaaaaofaclnaaacaaciaaadaaacaacjaaafaaabaackaaafaaacaaclaaahaaldabaeiaaaaaacaaaaaaaaaaaaaaaaaaaaaaaaaabjaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaabaagfaaaaaaaaaaaeaaaaaaaaaaaaaaaaaaaaaaabaagoaaaaaaaaaaaaaaaaaaabaaaaaaobajaaaaaaaaaadmengpgehfgmgfdoaaffhagegbhegfcogfhigfaaahpnooaaffhagegbhegfaaakcmcjbnbpcncnaocjcjcgaaakcmcjcbcmblchaabbbpbmanbpcococdcicbcnaaambpcncjcpcmbnbpcnaaffhagegbhegfcofahcgphagfhchegjgfhdaafdgfhehegjgoghhdaagnhdgdgphcgmgjgcaafdhjhdhegfgnaaepgcgkgfgdheaafdhjhdhegfgncoedgpgogggjghhfhcgbhegjgpgoaaebhahagmgjgdgbhegjgpgofdgfhehegjgoghhdecgbhdgfaapladaoanbjaoajbjpkbjplbdaopoaaplbdaopoanbjaoajbjpkbjbbajampnaapladaoanbjaoajbjpkbjbbajampnaappcdcgbpahpnooaacacdcgbpaocjancocmcdcicbaachbjcgajciplcdcocnaachbjcgolakcjdbbpcmaaagancccdcacoaaamancccdcacoaaamcjcoblcobpagbpcacoaapkboboapcicncdcbcibpboaachbooobjppaachbooobjabaachbooobjacaachbooobjadaachbooobjppppaachbooobjababaachbooobjacacaachbooobjadadaapmcjcidabpcmcoaocjbbcjcmbopkcmcmblddaabbcjcmboaocjacbpdcaaaocjacbpdcaacocjccbpdcaapocibncmddckcoaacogdhegphcaacobpcncoaacfcdcgcgakcmcjbnbpcncnpodcbpaacfcdcgcgakcmcjbnbpcncnaabobpcgblddaaakcmcjbnbpcncnadcnamcpcicicdcicbaaampoanaopkamaoaapkciblcgddcnbppkcmcbcnaaahblcdciaacpckboblcobpppcdcgbpaabnccbpbncfpncdcmbpbncocjcmddaaanbldabpppcdcgbpaacpckboblcobpadcicibpcmppcdcgbpcnaacbbpcopkcgcgppcdcgbpcnaacbbpcobbbpbmpnblcoblaacbbpcoaicjbobppnblcoblaafdhjhdhegfgncofcgfhdgphfhcgdgfhdaafcgfhdgphfhcgdgfengbgogbghgfhcaacmbpcncjcpcmbnbpahblciaafdhjhdhegfgncoehgmgpgcgbgmgjhkgbhegjgpgoaaedhfgmhehfhcgfejgogggpaacmbpcncjcpcmbnbppmcpcgcocpcmbpaacbbpcobjambpcncjcpcmbnbpahblciblcbbpcmaacbbpcobjpmcpcgcocpcmbpaacnbpcobjpmcpcgcocpcmbpaapmcpcgcocpcmbpaagegfgggbhfgmheejgohdhegbgogdgfaaghgfhefpeegfgggbhfgmheaaeegfgggbhfgmheaacacdcgbpakblcoccaacgbablcgcpbpaacdancccdcacoplcdcocnaacgbcaacgbdaadcaaddaadeaablaabmaabnaaboaacnaablbnaacnahbpcncnblcbbpaabobpbnaaccbpdcaacncoddckbpaabpdcbpppcdcgbpaackcmcjbnbpcncnaiblchbpaaahcdcgcgcdcnbpbncjcibocnaablcmcbcnaacpcmcgaachboooaaboblcoblaabncjcicacdcbapcmcgaabocdcmakblcoccaackbpcmcacddcaabobpcgbpcoajcmcoccbpcmcnaackblcoccaacicjbobpaiblchbpaacacdciblcgaicjbobpaadablcgcpbpaafdhjhdhegfgncofchfgohegjgngfcofggfhchdgjgpgogjgoghaafegbhcghgfheeghcgbgngfhhgphcglebhehehcgjgchfhegfaafdhjhdhegfgncofcgfgggmgfgdhegjgpgoaaebhdhdgfgngcgmhjfegjhegmgfebhehehcgjgchfhegfaaebhdhdgfgngcgmhjeegfhdgdhcgjhahegjgpgoebhehehcgjgchfhegfaaebhdhdgfgngcgmhjedgpgogggjghhfhcgbhegjgpgoebhehehcgjgchfhegfaaebhdhdgfgngcgmhjedgpgnhagbgohjebhehehcgjgchfhegfaaebhdhdgfgngcgmhjfahcgpgehfgdheebhehehcgjgchfhegfaaebhdhdgfgngcgmhjedgphahjhcgjghgiheebhehehcgjgchfhegfaaebhdhdgfgngcgmhjfehcgbgegfgngbhcglebhehehcgjgchfhegfaaebhdhdgfgngcgmhjedhfgmhehfhcgfebhehehcgjgchfhegfaafdhjhdhegfgncofchfgohegjgngfcoejgohegfhcgphafdgfhchggjgdgfhdaaedgpgnfggjhdgjgcgmgfebhehehcgjgchfhegfaaehhfgjgeebhehehcgjgchfhegfaaebhdhdgfgngcgmhjfggfhchdgjgpgoebhehehcgjgchfhegfaaebhdhdgfgngcgmhjeggjgmgffggfhchdgjgpgoebhehehcgjgchfhegfaafdhjhdhegfgncoeegjgbghgogphdhegjgdhdaaeegfgchfghghgbgcgmgfebhehehcgjgchfhegfaaeegfgchfghghgjgoghengpgegfhdaafdhjhdhegfgncofchfgohegjgngfcoedgpgnhagjgmgfhcfdgfhchggjgdgfhdaaedgpgnhagjgmgbhegjgpgofcgfgmgbhigbhegjgpgohdebhehehcgjgchfhegfaafchfgohegjgngfedgpgnhagbhegjgcgjgmgjhehjebhehehcgjgchfhegfaafdhjhdhegfgncoejepaaeggjgmgfaaefhigjhdhehdaafdhjhdhegfgncofegfhiheaaefgogdgpgegjgoghaafdhehcgfgbgnfcgfgbgegfhcaafegfhihefcgfgbgegfhcaafcgfgbgefegpefgogeaaedgmgphdgfaaeegjhdhagphdgfaaedgpgohggfhcheaafegpecgpgpgmgfgbgoaaehgfheechjhegfhdaaejgohedgdeaafdhehcgjgoghaaedgpgogdgbheaaghgfhefpemgfgoghhegiaafdhfgchdhehcgjgoghaafegpfdhehcgjgoghaaengbhegiaafagphhaafegpejgohedgdeaafegpemgphhgfhcaacogdgdhegphcaaefgogehdfhgjhegiaafagbhegiaaehgfheeggjgmgfeogbgngffhgjhegigphfheefhihegfgohdgjgpgoaafahcgpgdgfhdhdaaehgfhefahcgpgdgfhdhdgfhdechjeogbgngfaaelgjgmgmaaefhigdgfhahegjgpgoaaeegbhegffegjgngfaaghgfhefpeogphhaaebgegeengjgmgmgjhdgfgdgpgogehdaaghgfhefpfegjgdglhdaafdhjhdhegfgncoedgpgmgmgfgdhegjgpgohdcoehgfgogfhcgjgdaaemgjhdhegadbaaefhbhfgbgmhdaaebgegeaafegpebhchcgbhjaafdfeebfegihcgfgbgeebhehehcgjgchfhegfaafehcgjgnaaedgigbhcaafdhegbhchehdfhgjhegiaaebhahaeegpgngbgjgoaaghgfhefpedhfhchcgfgoheeegpgngbgjgoaaghgfhefpecgbhdgfeegjhcgfgdhegphchjaaehgfheeggjgmgfeogbgngfaaeegfgmgfhegfaafdhjhdhegfgncoeogfheaafhgfgcedgmgjgfgoheaaeegphhgogmgpgbgefdhehcgjgoghaaedgpgohegbgjgohdaafcgfhagmgbgdgfaaeegphhgogmgpgbgeeggjgmgfaafdhegbhcheaaehgfheeegjhcgfgdhegphchjeogbgngfaaeegjhcgfgdhegphchjaaeegjhcgfgdhegphchjejgogggpaaedhcgfgbhegfeegjhcgfgdhegphchjaaghgfhefpfffeegdiaafdhehcgfgbgnfhhcgjhegfhcaafegfhihefhhcgjhegfhcaafhhcgjhegfaaejgogegfhiepggaafdhagmgjheaafehcgjgnefgogeaaemgbhdheejgogegfhiepggaaefgohggjhcgpgogngfgoheaaefhigjheaafdhehcgjgoghechfgjgmgegfhcaaehgfheeggjgmgfhdaaebhahagfgogeaaehgfheeegjhcgfgdhegphcgjgfhdaahdgfhefpefgogdgpgegjgoghaafdhjhdhegfgncoedgpgegfeegpgncoedgpgnhagjgmgfhcaaehgfgogfhcgbhegfgeedgpgegfebhehehcgjgchfhegfaaeegfgchfghghgfhceogpgoffhdgfhcedgpgegfebhehehcgjgchfhegfaaedgpgnhagjgmgfhcehgfgogfhcgbhegfgeebhehehcgjgchfhegfaafcgfgggfhcgfgogdgfefhbhfgbgmhdaafehjhagfaafchfgohegjgngffehjhagfeigbgogegmgfaaehgfhefehjhagfeghcgpgneigbgogegmgfaaebhdhdgfgngcgmhjaaghgfhefpebhdhdgfgngcgmhjaafdhjhdhegfgncoedgpgnhagpgogfgoheengpgegfgmaaefgegjhegphcechcgphhhdgbgcgmgfebhehehcgjgchfhegfaaefgegjhegphcechcgphhhdgbgcgmgffdhegbhegfaafdgfhehegjgoghhdecgbhdgfaafdhjgogdgihcgpgogjhkgfgeaaffhagegbhegfcofahcgphagfhchegjgfhdcofcgfhdgphfhcgdgfhdcohcgfhdgphfhcgdgfhdaaaaaaabaaaddaaaaaadgbaaaaadgcaaaaadgdaaaaadgeaaaaadgfaaaaadggaaaabpedaagiaagbaahcaaghaagfaaenaagpaageaahfaagmaagfaafpaafgaadeaaaaajcoaagfaahiaagfaaaaapfcaaefaafdaafeaaebaafcaafeaaaabbflaaedaaepaaeoaaegaaejaaehaafnaaaaalggaagbaagmaahdaagfaaaablffaahaaageaagbaaheaagfaafpaaegaagjaagmaagfaahdaafmaaaaajcoaaheaahiaaheaaaaadakaaaaafanaaakaaaaafcnaadoaaabapanghkbfcgifgeeinjagooohgfffpabaliffppegglagfihgfpgeoabadfmaaaaadcpaaaaadciaaaaaddlaaaaadcjaaaadhffaahaaageaagbaaheaagfaacoaafaaahcaagpaahaaagfaahcaaheaagjaagfaahdaacoaafcaagfaahdaagpaahfaahcaagdaagfaahdaaaaaaaaaamcboonmpgpkpbkelilgoeckbblgacjhfaaailhhkfmfgbjdeoaijacagaiaeaiaaaaaaaeaeaaaaaaaecaaaaaaaaeaaabaoaoadagbnakafaaacakakakagaaadakakakakalaaahabbaakakakakakakakafaaabbnakaoaeaaabaoakafaaacaoaoaiadcaaaabadaaaaabaeaaababaoaeaaababanaeaaabacaoacagacagaaabbnaobnaoafaaababbnaoagaaadabaoaoaoafaaacaoaoaoahaaaeabaoaoaoacagaaadaoaoaoacadagbcanadagbcbbaeaaaabcanaeaaaabcbbafaaababbcbbaeaiaabcanaeaiaabcbbadagbcbmaeaaaabcbmaeaiaabcbmababaecaababaoaecaababacafcaababbbenaecaababaiagahaeaoaoaoacaeaaaabcfnagcaacabaobcfnadcaaaaoahahaeaobcgbaoacaeaaabacakafahadakakacaeahacakakakahaiakakakakakakakacafcaabbnafaobaahakbnakaiaibnakaiaiaibnafbnakacadcaaaaiaecaabaoaiaiahagaoakaiaiaoacafahadaoaoacafahadaoaoakafaaacanananaeaaabakanahaaaeaoaoaoaoaobbahaoaoaibnakaiakakakakakakakakaoacadahabaoaecaabacaoaeahacaoacagaaabbnbchnaoapahagbnbchnbchnbciaibbnbchnaiacafaaaabbiaifagcaabbbiaifanadcaaaakahahadakbbiaifacahahadbnbchnacacagbfbciaijabaoafcaababbdaaafcaaabnbdaaapahagbfbciaijabaoaobnaoacbnaoaiaeabaaaaaaafcaabaobnadajahagaoaoaoaoacbnadafaaaabciajfagaaadaoaoaoaoaecaabaoaoafcaacaoaoaoafcaacabaoaoafaaabbchnaoaiahaeaobciajjaoacagaaabbciakbaoahcaadabaoacbcfnagahacbciakfaoaecaabaiaoafcaacaoaiaiagcaabbnaobnadafcaabacbdaaaeaaababaiboahbdaoaiaoaoaobnaobfbciaijabaoaoaoaoaoaoaobnaoaoacbnadbnaoaiafaaabbnaoaoagcaabbcialbaobbahakbcialbbnaoaobnaoaoaoaoacbnaoaiafcaababbcfnahahadbciajjaoaoafcaacaiaoaiahahafaoaoaiaiaoeaabaaddfdhjhdhegfgncofcgfhdgphfhcgdgfhdcofegpgpgmhdcofdhehcgpgoghgmhjfehjhagfgefcgfhdgphfhcgdgfechfgjgmgegfhcahdecodacodacodaaaaaafaaacacbmbmaiaaabbciambbbiamfafcaaabciamjahcaacabaobciamjahahadbcanbcanacaeahabbcbbagcaababbbianbaiabaaacaaaaaaaaaafjabaaelengjgdhcgphdgpgghecofggjhdhfgbgmfdhehfgegjgpcoefgegjhegphchdcofdgfhehegjgoghhdeegfhdgjghgogfhccofdgfhehegjgoghhdfdgjgoghgmgfeggjgmgfehgfgogfhcgbhegphcaidbdbcodacodacodaaaaaaeahabbcbmaiaaabbcianfbcianfehabaabkcoeoeffeeghcgbgngfhhgphcglcmfggfhchdgjgpgodnhgdecodaabaafeaobeeghcgbgngfhhgphcgleegjhdhagmgbhjeogbgngfbacoeoeffecaeghcgbgngfhhgphcglcadealabaaagffhagegbhegfaaaabnabaabiogjgihoelllgogjlleogjglaoiloifofikkjoflhkfofiflhaaaaafabaaaaaaaaanabaaaifdgdgjgngfgogdgfaaaabpabaabkedgphahjhcgjghgihecamckjcafdgdgjgngfgogdgfcadcdadbdhaaaacjabaacededgdgdadedhdddccndhgcdagccndedidggecndjdbdddfcngddgdedfggggdddggegddjdiaaaaamabaaahdccodacodacodaaaaaaiabaaahabaaaaaaaaaiabaaaiaaaaaaaaaaboabaaabaafeacbgfhhcgbhaeogpgoefhigdgfhahegjgpgofegihcgphhhdabaaaaaaaaaaaajegijffjaaaaaaaaacaaaaaabmabaaaabaffaaaabadhaaaafcfdeefdklekaebcijacbhekjghdlkdmjglkihpecaaaaaaagedkfmhdgdgjfmfggjhdhfgbgmcafdhehfgegjgpcadcdadadifmfahcgpgkgfgdhehdfmffhagegbhegffmffhagegbhegffmgpgcgkfmeegfgchfghfmffhagegbhegfcohagegcaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafefgaaaaaaaaaaaaaaaaaaaagofgaaaaaacaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaagafgaaaaaaaaaaaaaaaaaaaaaaaafpedgphcefhigfengbgjgoaagnhdgdgphcgfgfcogegmgmaaaaaaaaaappcfaacaeaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaacaabaaaaaaacaaaaaiabiaaaaaadiaaaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabaaabaaaaaafaaaaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabaaabaaaaaagiaaaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabaaaaaaaaaaiaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabaaaaaaaaaajaaaaaaakagaaaaabaadaaaaaaaaaaaaaaaaaaaalagdaaaaokabaaaaaaaaaaaaaaaaaaaabaaddeaaaaaafgaafdaafpaafgaaefaafcaafdaaejaaepaaeoaafpaaejaaeoaaegaaepaaaaaaaaaalnaeoppoaaaaabaaaaaaacaaaaaaaaaaaaaaacaaaaaaaaaadpaaaaaaaaaaaaaaaeaaaaaaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaeeaaaaaaabaafgaagbaahcaaegaagjaagmaagfaaejaagoaaggaagpaaaaaaaaaaceaaaeaaaaaafeaahcaagbaagoaahdaagmaagbaaheaagjaagpaagoaaaaaaaaaaaaaalaaehaacaaaaabaafdaaheaahcaagjaagoaaghaaegaagjaagmaagfaaejaagoaaggaagpaaaaaaemacaaaaabaadaaadaaadaaadaaadaaadeaagcaadaaaaaaacmaaajaaabaaedaagpaagnaagnaagfaagoaaheaahdaaaaaaihgfpgeopegglagfifipkjfcoffnhhfbaaaaaaaadeaaajaaabaaedaagpaagnaahaaagbaagoaahjaaeoaagbaagnaagfaaaaaaaaaafdaagdaagjaagnaagfaagoaagdaagfaaaaaaaaaadiaaahaaabaaegaagjaagmaagfaaeeaagfaahdaagdaahcaagjaahaaaheaagjaagpaagoaaaaaaaaaaffaahaaageaagbaaheaagfaaaaaaaaaadaaaaiaaabaaegaagjaagmaagfaafgaagfaahcaahdaagjaagpaagoaaaaaaaaaadcaacoaadaaacoaadaaacoaadaaaaaaadiaaalaaabaaejaagoaaheaagfaahcaagoaagbaagmaaeoaagbaagnaagfaaaaaaffaahaaageaagbaaheaagfaacoaagfaahiaagfaaaaaaaaaafiaabkaaabaaemaagfaaghaagbaagmaaedaagpaahaaahjaahcaagjaaghaagiaaheaaaaaaedaagpaahaaahjaahcaagjaaghaagiaaheaacaaakjaacaaafdaagdaagjaagnaagfaagoaagdaagfaacaaadcaadaaadbaadhaaaaaaeaaaalaaabaaepaahcaagjaaghaagjaagoaagbaagmaaegaagjaagmaagfaagoaagbaagnaagfaaaaaaffaahaaageaagbaaheaagfaacoaagfaahiaagfaaaaaaaaaadaaaahaaabaafaaahcaagpaageaahfaagdaaheaaeoaagbaagnaagfaaaaaaaaaaffaahaaageaagbaaheaagfaaaaaaaaaadeaaaiaaabaafaaahcaagpaageaahfaagdaaheaafgaagfaahcaahdaagjaagpaagoaaaaaadcaacoaadaaacoaadaaacoaadaaaaaaadiaaaiaaabaaebaahdaahdaagfaagnaagcaagmaahjaacaaafgaagfaahcaahdaagjaagpaagoaaaaaadcaacoaadaaacoaadaaacoaadaaaaaaaoplllpdmdphigngmcahggfhchdgjgpgodnccdbcodacccagfgogdgpgegjgoghdnccfffeegcndicccahdhegbgogegbgmgpgogfdncchjgfhdccdpdoanakdmgbhdhdgfgngcgmhjcahigngmgohddncchfhcgodkhdgdgigfgngbhdcngngjgdhcgphdgpgghecngdgpgndkgbhdgncohgdbcccagngbgogjgggfhdhefggfhchdgjgpgodnccdbcodaccdoanakcacadmgbhdhdgfgngcgmhjejgegfgohegjhehjcahggfhchdgjgpgodnccdbcodacodacodacccagogbgngfdnccenhjebhahagmgjgdgbhegjgpgocogbhahacccpdoanakcacadmhehchfhdheejgogggpcahigngmgohddncchfhcgodkhdgdgigfgngbhdcngngjgdhcgphdgpgghecngdgpgndkgbhdgncohgdcccdoanakcacacacadmhdgfgdhfhcgjhehjdoanakcacacacacacadmhcgfhbhfgfhdhegfgefahcgjhggjgmgfghgfhdcahigngmgohddncchfhcgodkhdgdgigfgngbhdcngngjgdhcgphdgpgghecngdgpgndkgbhdgncohgddccdoanakcacacacacacacacadmhcgfhbhfgfhdhegfgeefhigfgdhfhegjgpgoemgfhggfgmcagmgfhggfgmdnccgbhdejgohggpglgfhccccahfgjebgdgdgfhdhddnccgggbgmhdgfcccpdoanakcacacacacacadmcphcgfhbhfgfhdhegfgefahcgjhggjgmgfghgfhddoanakcacacacadmcphdgfgdhfhcgjhehjdoanakcacadmcphehchfhdheejgogggpdoanakdmcpgbhdhdgfgngcgmhjdoanakaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafaaaaaamaaaaaaiadgaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    }


}
