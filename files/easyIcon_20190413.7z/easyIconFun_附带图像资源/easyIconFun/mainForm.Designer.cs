﻿namespace easyIconFun
{
    partial class mainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            //System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.panelMain = new System.Windows.Forms.Panel();
            this.contextMenu_curExport = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem_saveCurPng = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveCurIcon = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveCurJpg = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_cur_split = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem_preview = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBoxMain = new System.Windows.Forms.PictureBox();
            this.menuStrip_main = new System.Windows.Forms.MenuStrip();
            this.MenuItem_Export = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_savePng = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveIcon = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveJpg = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_setting = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_Center = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_set_split = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem_Dir = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_wikiInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_pollCode = new System.Windows.Forms.ToolStripMenuItem();
            this.panelBody = new System.Windows.Forms.Panel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.StatusSizeLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusSize = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatusTipInfo = new System.Windows.Forms.ToolStripStatusLabel();
            this.panelRightT = new System.Windows.Forms.Panel();
            this.labelFile = new System.Windows.Forms.Label();
            this.checkBoxAllFile = new System.Windows.Forms.CheckBox();
            this.ListBox_Name = new System.Windows.Forms.CheckedListBox();
            this.contextMenu_ExportAll = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem_savePngAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveIconAll = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_saveJpgAll = new System.Windows.Forms.ToolStripMenuItem();
            this.panelRightB = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox_width = new System.Windows.Forms.TextBox();
            this.textBox_height = new System.Windows.Forms.TextBox();
            this.button_newSize = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ListBox_Size = new System.Windows.Forms.CheckedListBox();
            this.contextMenu_Size = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuItem0 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItem_split1 = new System.Windows.Forms.ToolStripSeparator();
            this.MenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.labelSize = new System.Windows.Forms.Label();
            this.checkBoxAllSize = new System.Windows.Forms.CheckBox();
            this.PanelLeft = new System.Windows.Forms.FlowLayoutPanel();
            this.style_0 = new System.Windows.Forms.Button();
            this.style_1 = new System.Windows.Forms.Button();
            this.style_2 = new System.Windows.Forms.Button();
            this.style_3 = new System.Windows.Forms.Button();
            this.style_4 = new System.Windows.Forms.Button();
            this.style_5 = new System.Windows.Forms.Button();
            this.style_6 = new System.Windows.Forms.Button();
            this.style_7 = new System.Windows.Forms.Button();
            this.style_8 = new System.Windows.Forms.Button();
            this.style_9 = new System.Windows.Forms.Button();
            this.style_self = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.mini = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.FormIcon = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelMain.SuspendLayout();
            this.contextMenu_curExport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).BeginInit();
            this.menuStrip_main.SuspendLayout();
            this.panelBody.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.panelRightT.SuspendLayout();
            this.contextMenu_ExportAll.SuspendLayout();
            this.panelRightB.SuspendLayout();
            this.panel2.SuspendLayout();
            this.contextMenu_Size.SuspendLayout();
            this.PanelLeft.SuspendLayout();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FormIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.panelMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMain.ContextMenuStrip = this.contextMenu_curExport;
            this.panelMain.Controls.Add(this.pictureBoxMain);
            this.panelMain.Location = new System.Drawing.Point(38, 25);
            this.panelMain.Margin = new System.Windows.Forms.Padding(0);
            this.panelMain.Name = "panelMain";
            this.panelMain.Size = new System.Drawing.Size(400, 400);
            this.panelMain.TabIndex = 25;
            this.toolTip1.SetToolTip(this.panelMain, "拖动图像文件至此，完成载入\r\n可拖入若干个图像文件，或包含图像的文件夹");
            // 
            // contextMenu_curExport
            // 
            this.contextMenu_curExport.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_saveCurPng,
            this.MenuItem_saveCurIcon,
            this.MenuItem_saveCurJpg,
            this.MenuItem_cur_split,
            this.MenuItem_preview});
            this.contextMenu_curExport.Name = "contextMenu_curExport";
            this.contextMenu_curExport.Size = new System.Drawing.Size(125, 98);
            // 
            // MenuItem_saveCurPng
            // 
            this.MenuItem_saveCurPng.Name = "MenuItem_saveCurPng";
            this.MenuItem_saveCurPng.Size = new System.Drawing.Size(124, 22);
            this.MenuItem_saveCurPng.Text = "导出png";
            this.MenuItem_saveCurPng.ToolTipText = "当前图像，导出为png格式\r\n对所有选中的尺寸执行操作（默认为原尺寸）";
            this.MenuItem_saveCurPng.Click += new System.EventHandler(this.MenuItem_saveCurPng_Click);
            // 
            // MenuItem_saveCurIcon
            // 
            this.MenuItem_saveCurIcon.Name = "MenuItem_saveCurIcon";
            this.MenuItem_saveCurIcon.Size = new System.Drawing.Size(124, 22);
            this.MenuItem_saveCurIcon.Text = "导出icon";
            this.MenuItem_saveCurIcon.ToolTipText = "当前图像，导出为ico格式\r\n对所有选中的尺寸执行操作（默认为原尺寸）";
            this.MenuItem_saveCurIcon.Click += new System.EventHandler(this.MenuItem_saveCurIcon_Click);
            // 
            // MenuItem_saveCurJpg
            // 
            this.MenuItem_saveCurJpg.Name = "MenuItem_saveCurJpg";
            this.MenuItem_saveCurJpg.Size = new System.Drawing.Size(124, 22);
            this.MenuItem_saveCurJpg.Text = "导出jpg";
            this.MenuItem_saveCurJpg.ToolTipText = "当前图像，导出为jpg格式\r\n对所有选中的尺寸执行操作（默认为原尺寸）";
            this.MenuItem_saveCurJpg.Click += new System.EventHandler(this.MenuItem_saveCurJpg_Click);
            // 
            // MenuItem_cur_split
            // 
            this.MenuItem_cur_split.Name = "MenuItem_cur_split";
            this.MenuItem_cur_split.Size = new System.Drawing.Size(121, 6);
            // 
            // MenuItem_preview
            // 
            this.MenuItem_preview.CheckOnClick = true;
            this.MenuItem_preview.Name = "MenuItem_preview";
            this.MenuItem_preview.Size = new System.Drawing.Size(124, 22);
            this.MenuItem_preview.Text = "预览";
            this.MenuItem_preview.ToolTipText = "预览模式显示，最终导出的图像";
            this.MenuItem_preview.Click += new System.EventHandler(this.MenuItem_preview_Click);
            // 
            // pictureBoxMain
            // 
            this.pictureBoxMain.BackgroundImage = global::easyIconFun.Properties.Resources.TransBg;
            this.pictureBoxMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxMain.ContextMenuStrip = this.contextMenu_curExport;
            this.pictureBoxMain.Location = new System.Drawing.Point(100, 100);
            this.pictureBoxMain.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBoxMain.Name = "pictureBoxMain";
            this.pictureBoxMain.Size = new System.Drawing.Size(200, 200);
            this.pictureBoxMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMain.TabIndex = 11;
            this.pictureBoxMain.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBoxMain, "拖动图像文件至此，完成载入\r\n可拖入若干个图像文件，或包含图像的文件夹");
            this.pictureBoxMain.Click += new System.EventHandler(this.pictureBoxMain_Click);
            // 
            // menuStrip_main
            // 
            this.menuStrip_main.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.menuStrip_main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_Export,
            this.MenuItem_setting,
            this.帮助HToolStripMenuItem});
            this.menuStrip_main.Location = new System.Drawing.Point(0, 0);
            this.menuStrip_main.Name = "menuStrip_main";
            this.menuStrip_main.Size = new System.Drawing.Size(639, 25);
            this.menuStrip_main.TabIndex = 30;
            this.menuStrip_main.Text = "menuStrip1";
            // 
            // MenuItem_Export
            // 
            this.MenuItem_Export.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_savePng,
            this.MenuItem_saveIcon,
            this.MenuItem_saveJpg});
            this.MenuItem_Export.Name = "MenuItem_Export";
            this.MenuItem_Export.Size = new System.Drawing.Size(84, 21);
            this.MenuItem_Export.Text = "批量导出(&A)";
            this.MenuItem_Export.ToolTipText = "批量处理图像，\r\n对所有选中的（图像、尺寸）执行操作";
            // 
            // MenuItem_savePng
            // 
            this.MenuItem_savePng.Name = "MenuItem_savePng";
            this.MenuItem_savePng.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.MenuItem_savePng.Size = new System.Drawing.Size(167, 22);
            this.MenuItem_savePng.Text = "导出png";
            this.MenuItem_savePng.ToolTipText = "批量导出png图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_savePng.Click += new System.EventHandler(this.MenuItem_savePng_Click);
            // 
            // MenuItem_saveIcon
            // 
            this.MenuItem_saveIcon.Name = "MenuItem_saveIcon";
            this.MenuItem_saveIcon.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.MenuItem_saveIcon.Size = new System.Drawing.Size(167, 22);
            this.MenuItem_saveIcon.Text = "导出icon";
            this.MenuItem_saveIcon.ToolTipText = "批量导出icon图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_saveIcon.Click += new System.EventHandler(this.MenuItem_saveIcon_Click);
            // 
            // MenuItem_saveJpg
            // 
            this.MenuItem_saveJpg.Name = "MenuItem_saveJpg";
            this.MenuItem_saveJpg.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.J)));
            this.MenuItem_saveJpg.Size = new System.Drawing.Size(167, 22);
            this.MenuItem_saveJpg.Text = "导出jpg";
            this.MenuItem_saveJpg.ToolTipText = "批量导出jpg图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_saveJpg.Click += new System.EventHandler(this.MenuItem_saveJpg_Click);
            // 
            // MenuItem_setting
            // 
            this.MenuItem_setting.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_Center,
            this.MenuItem_set_split,
            this.MenuItem_Dir});
            this.MenuItem_setting.Name = "MenuItem_setting";
            this.MenuItem_setting.Size = new System.Drawing.Size(59, 21);
            this.MenuItem_setting.Text = "设置(&S)";
            // 
            // MenuItem_Center
            // 
            this.MenuItem_Center.CheckOnClick = true;
            this.MenuItem_Center.Name = "MenuItem_Center";
            this.MenuItem_Center.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.MenuItem_Center.Size = new System.Drawing.Size(170, 22);
            this.MenuItem_Center.Text = "居中裁切";
            this.MenuItem_Center.ToolTipText = "原图像按长宽比缩放至大于目标尺寸，\r\n目标尺寸居中且最适于缩放后的尺寸";
            // 
            // MenuItem_set_split
            // 
            this.MenuItem_set_split.Name = "MenuItem_set_split";
            this.MenuItem_set_split.Size = new System.Drawing.Size(167, 6);
            // 
            // MenuItem_Dir
            // 
            this.MenuItem_Dir.Name = "MenuItem_Dir";
            this.MenuItem_Dir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.MenuItem_Dir.Size = new System.Drawing.Size(170, 22);
            this.MenuItem_Dir.Text = "软件目录";
            this.MenuItem_Dir.ToolTipText = "打开软件的存储目录";
            this.MenuItem_Dir.Click += new System.EventHandler(this.MenuItem_Dir_Click);
            // 
            // 帮助HToolStripMenuItem
            // 
            this.帮助HToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_wikiInfo,
            this.MenuItem_pollCode});
            this.帮助HToolStripMenuItem.Name = "帮助HToolStripMenuItem";
            this.帮助HToolStripMenuItem.Size = new System.Drawing.Size(61, 21);
            this.帮助HToolStripMenuItem.Text = "帮助(&H)";
            // 
            // MenuItem_wikiInfo
            // 
            this.MenuItem_wikiInfo.Name = "MenuItem_wikiInfo";
            this.MenuItem_wikiInfo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.MenuItem_wikiInfo.Size = new System.Drawing.Size(174, 22);
            this.MenuItem_wikiInfo.Text = "使用说明";
            this.MenuItem_wikiInfo.Click += new System.EventHandler(this.MenuItem_wiki_Click);
            // 
            // MenuItem_pollCode
            // 
            this.MenuItem_pollCode.Name = "MenuItem_pollCode";
            this.MenuItem_pollCode.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.MenuItem_pollCode.Size = new System.Drawing.Size(174, 22);
            this.MenuItem_pollCode.Text = "软件注册";
            this.MenuItem_pollCode.ToolTipText = "使用正式版，去除\"您未注册\"";
            this.MenuItem_pollCode.Click += new System.EventHandler(this.软件注册ToolStripMenuItem_Click);
            // 
            // panelBody
            // 
            this.panelBody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelBody.Controls.Add(this.statusStrip);
            this.panelBody.Controls.Add(this.panelRightT);
            this.panelBody.Controls.Add(this.panelRightB);
            this.panelBody.Controls.Add(this.panelMain);
            this.panelBody.Controls.Add(this.PanelLeft);
            this.panelBody.Controls.Add(this.menuStrip_main);
            this.panelBody.Location = new System.Drawing.Point(0, 47);
            this.panelBody.Name = "panelBody";
            this.panelBody.Size = new System.Drawing.Size(641, 449);
            this.panelBody.TabIndex = 31;
            // 
            // statusStrip
            // 
            this.statusStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StatusSizeLabel,
            this.StatusSize,
            this.toolStripStatusLabel2,
            this.StatusTipInfo});
            this.statusStrip.Location = new System.Drawing.Point(0, 425);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(639, 22);
            this.statusStrip.TabIndex = 35;
            this.statusStrip.Text = "statusStrip1";
            // 
            // StatusSizeLabel
            // 
            this.StatusSizeLabel.Name = "StatusSizeLabel";
            this.StatusSizeLabel.Size = new System.Drawing.Size(92, 17);
            this.StatusSizeLabel.Text = "当前图像尺寸：";
            // 
            // StatusSize
            // 
            this.StatusSize.Name = "StatusSize";
            this.StatusSize.Size = new System.Drawing.Size(29, 17);
            this.StatusSize.Text = "0, 0";
            this.StatusSize.Click += new System.EventHandler(this.MenuItem1_Click);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(11, 17);
            this.toolStripStatusLabel2.Text = "|";
            // 
            // StatusTipInfo
            // 
            this.StatusTipInfo.Name = "StatusTipInfo";
            this.StatusTipInfo.Size = new System.Drawing.Size(16, 17);
            this.StatusTipInfo.Text = "  ";
            this.StatusTipInfo.ToolTipText = "\"  \"";
            // 
            // panelRightT
            // 
            this.panelRightT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.panelRightT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRightT.Controls.Add(this.labelFile);
            this.panelRightT.Controls.Add(this.checkBoxAllFile);
            this.panelRightT.Controls.Add(this.ListBox_Name);
            this.panelRightT.Location = new System.Drawing.Point(437, 25);
            this.panelRightT.Name = "panelRightT";
            this.panelRightT.Size = new System.Drawing.Size(204, 186);
            this.panelRightT.TabIndex = 34;
            // 
            // labelFile
            // 
            this.labelFile.AutoSize = true;
            this.labelFile.Location = new System.Drawing.Point(3, 5);
            this.labelFile.Name = "labelFile";
            this.labelFile.Size = new System.Drawing.Size(53, 12);
            this.labelFile.TabIndex = 29;
            this.labelFile.Text = "选择图像";
            // 
            // checkBoxAllFile
            // 
            this.checkBoxAllFile.AutoSize = true;
            this.checkBoxAllFile.Location = new System.Drawing.Point(154, 3);
            this.checkBoxAllFile.Name = "checkBoxAllFile";
            this.checkBoxAllFile.Size = new System.Drawing.Size(48, 16);
            this.checkBoxAllFile.TabIndex = 28;
            this.checkBoxAllFile.Text = "全选";
            this.toolTip1.SetToolTip(this.checkBoxAllFile, "全选或全不选，所有图像");
            this.checkBoxAllFile.UseVisualStyleBackColor = true;
            this.checkBoxAllFile.CheckedChanged += new System.EventHandler(this.checkBoxAllFile_CheckedChanged);
            // 
            // ListBox_Name
            // 
            this.ListBox_Name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.ListBox_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ListBox_Name.CheckOnClick = true;
            this.ListBox_Name.ContextMenuStrip = this.contextMenu_ExportAll;
            this.ListBox_Name.FormattingEnabled = true;
            this.ListBox_Name.Location = new System.Drawing.Point(0, 22);
            this.ListBox_Name.Name = "ListBox_Name";
            this.ListBox_Name.Size = new System.Drawing.Size(201, 162);
            this.ListBox_Name.TabIndex = 27;
            this.toolTip1.SetToolTip(this.ListBox_Name, "在此处选择，待处理的图像");
            this.ListBox_Name.SelectedIndexChanged += new System.EventHandler(this.ListBox_Name_SelectedIndexChanged);
            // 
            // contextMenu_ExportAll
            // 
            this.contextMenu_ExportAll.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem_savePngAll,
            this.MenuItem_saveIconAll,
            this.MenuItem_saveJpgAll});
            this.contextMenu_ExportAll.Name = "contextMenu_ExportAll";
            this.contextMenu_ExportAll.Size = new System.Drawing.Size(149, 70);
            // 
            // MenuItem_savePngAll
            // 
            this.MenuItem_savePngAll.Name = "MenuItem_savePngAll";
            this.MenuItem_savePngAll.Size = new System.Drawing.Size(148, 22);
            this.MenuItem_savePngAll.Text = "批量导出png";
            this.MenuItem_savePngAll.ToolTipText = "批量导出png图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_savePngAll.Click += new System.EventHandler(this.MenuItem_savePng_Click);
            // 
            // MenuItem_saveIconAll
            // 
            this.MenuItem_saveIconAll.Name = "MenuItem_saveIconAll";
            this.MenuItem_saveIconAll.Size = new System.Drawing.Size(148, 22);
            this.MenuItem_saveIconAll.Text = "批量导出icon";
            this.MenuItem_saveIconAll.ToolTipText = "批量导出icon图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_saveIconAll.Click += new System.EventHandler(this.MenuItem_saveIcon_Click);
            // 
            // MenuItem_saveJpgAll
            // 
            this.MenuItem_saveJpgAll.Name = "MenuItem_saveJpgAll";
            this.MenuItem_saveJpgAll.Size = new System.Drawing.Size(148, 22);
            this.MenuItem_saveJpgAll.Text = "批量导出jpg";
            this.MenuItem_saveJpgAll.ToolTipText = "批量导出jpg图像\r\n对所有选中的（图像、尺寸）执行操作";
            this.MenuItem_saveJpgAll.Click += new System.EventHandler(this.MenuItem_saveJpg_Click);
            // 
            // panelRightB
            // 
            this.panelRightB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.panelRightB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRightB.Controls.Add(this.panel2);
            this.panelRightB.Controls.Add(this.ListBox_Size);
            this.panelRightB.Controls.Add(this.labelSize);
            this.panelRightB.Controls.Add(this.checkBoxAllSize);
            this.panelRightB.Location = new System.Drawing.Point(437, 210);
            this.panelRightB.Name = "panelRightB";
            this.panelRightB.Size = new System.Drawing.Size(204, 215);
            this.panelRightB.TabIndex = 33;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.panel2.Controls.Add(this.textBox_width);
            this.panel2.Controls.Add(this.textBox_height);
            this.panel2.Controls.Add(this.button_newSize);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 184);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 30);
            this.panel2.TabIndex = 35;
            // 
            // textBox_width
            // 
            this.textBox_width.Location = new System.Drawing.Point(24, 4);
            this.textBox_width.Name = "textBox_width";
            this.textBox_width.Size = new System.Drawing.Size(50, 21);
            this.textBox_width.TabIndex = 33;
            this.textBox_width.TextChanged += new System.EventHandler(this.textBox_width_TextChanged);
            this.textBox_width.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNumberInput);
            // 
            // textBox_height
            // 
            this.textBox_height.Location = new System.Drawing.Point(98, 4);
            this.textBox_height.Name = "textBox_height";
            this.textBox_height.Size = new System.Drawing.Size(50, 21);
            this.textBox_height.TabIndex = 35;
            this.textBox_height.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.onlyNumberInput);
            // 
            // button_newSize
            // 
            this.button_newSize.Location = new System.Drawing.Point(155, 3);
            this.button_newSize.Name = "button_newSize";
            this.button_newSize.Size = new System.Drawing.Size(39, 23);
            this.button_newSize.TabIndex = 37;
            this.button_newSize.Text = "添加";
            this.button_newSize.UseVisualStyleBackColor = true;
            this.button_newSize.Click += new System.EventHandler(this.button_newSize_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 36;
            this.label2.Text = "高：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 34;
            this.label1.Text = "宽：";
            // 
            // ListBox_Size
            // 
            this.ListBox_Size.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.ListBox_Size.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ListBox_Size.CheckOnClick = true;
            this.ListBox_Size.ContextMenuStrip = this.contextMenu_Size;
            this.ListBox_Size.FormattingEnabled = true;
            this.ListBox_Size.Location = new System.Drawing.Point(0, 21);
            this.ListBox_Size.Name = "ListBox_Size";
            this.ListBox_Size.Size = new System.Drawing.Size(202, 162);
            this.ListBox_Size.TabIndex = 31;
            this.toolTip1.SetToolTip(this.ListBox_Size, "在此选择，要导出的图像尺寸");
            // 
            // contextMenu_Size
            // 
            this.contextMenu_Size.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuItem0,
            this.toolStripSeparator1,
            this.MenuItem1,
            this.MenuItem2,
            this.MenuItem3,
            this.MenuItem_split1,
            this.MenuItem4});
            this.contextMenu_Size.Name = "contextMenu_Size";
            this.contextMenu_Size.Size = new System.Drawing.Size(150, 126);
            // 
            // MenuItem0
            // 
            this.MenuItem0.Name = "MenuItem0";
            this.MenuItem0.Size = new System.Drawing.Size(149, 22);
            this.MenuItem0.Text = "常用Icon尺寸";
            this.MenuItem0.ToolTipText = "在尺寸列表中，显示预设的常用尺寸";
            this.MenuItem0.Click += new System.EventHandler(this.MenuItem0_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(146, 6);
            // 
            // MenuItem1
            // 
            this.MenuItem1.Name = "MenuItem1";
            this.MenuItem1.Size = new System.Drawing.Size(149, 22);
            this.MenuItem1.Text = "添加当前尺寸";
            this.MenuItem1.ToolTipText = "添加当前显示的图像尺寸，到尺寸列表";
            this.MenuItem1.Click += new System.EventHandler(this.MenuItem1_Click);
            // 
            // MenuItem2
            // 
            this.MenuItem2.Name = "MenuItem2";
            this.MenuItem2.Size = new System.Drawing.Size(149, 22);
            this.MenuItem2.Text = "删除所选尺寸";
            this.MenuItem2.ToolTipText = "从尺寸列表中移除";
            this.MenuItem2.Click += new System.EventHandler(this.MenuItem2_Click);
            // 
            // MenuItem3
            // 
            this.MenuItem3.Name = "MenuItem3";
            this.MenuItem3.Size = new System.Drawing.Size(149, 22);
            this.MenuItem3.Text = "删除所有尺寸";
            this.MenuItem3.ToolTipText = "清空当前尺寸列表";
            this.MenuItem3.Click += new System.EventHandler(this.MenuItem3_Click);
            // 
            // MenuItem_split1
            // 
            this.MenuItem_split1.Name = "MenuItem_split1";
            this.MenuItem_split1.Size = new System.Drawing.Size(146, 6);
            // 
            // MenuItem4
            // 
            this.MenuItem4.CheckOnClick = true;
            this.MenuItem4.Name = "MenuItem4";
            this.MenuItem4.Size = new System.Drawing.Size(149, 22);
            this.MenuItem4.Text = "记住所有尺寸";
            this.MenuItem4.ToolTipText = "记忆当前尺寸信息，方便下次使用";
            this.MenuItem4.Click += new System.EventHandler(this.MenuItem4_Click);
            // 
            // labelSize
            // 
            this.labelSize.AutoSize = true;
            this.labelSize.Location = new System.Drawing.Point(3, 3);
            this.labelSize.Name = "labelSize";
            this.labelSize.Size = new System.Drawing.Size(53, 12);
            this.labelSize.TabIndex = 30;
            this.labelSize.Text = "导出尺寸";
            // 
            // checkBoxAllSize
            // 
            this.checkBoxAllSize.AutoSize = true;
            this.checkBoxAllSize.Location = new System.Drawing.Point(155, 3);
            this.checkBoxAllSize.Name = "checkBoxAllSize";
            this.checkBoxAllSize.Size = new System.Drawing.Size(48, 16);
            this.checkBoxAllSize.TabIndex = 29;
            this.checkBoxAllSize.Text = "全选";
            this.toolTip1.SetToolTip(this.checkBoxAllSize, "全选或全不选，所有尺寸");
            this.checkBoxAllSize.UseVisualStyleBackColor = true;
            this.checkBoxAllSize.CheckedChanged += new System.EventHandler(this.checkBoxAllSize_CheckedChanged);
            // 
            // PanelLeft
            // 
            this.PanelLeft.AllowDrop = true;
            this.PanelLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.PanelLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PanelLeft.Controls.Add(this.style_0);
            this.PanelLeft.Controls.Add(this.style_1);
            this.PanelLeft.Controls.Add(this.style_2);
            this.PanelLeft.Controls.Add(this.style_3);
            this.PanelLeft.Controls.Add(this.style_4);
            this.PanelLeft.Controls.Add(this.style_5);
            this.PanelLeft.Controls.Add(this.style_6);
            this.PanelLeft.Controls.Add(this.style_7);
            this.PanelLeft.Controls.Add(this.style_8);
            this.PanelLeft.Controls.Add(this.style_9);
            this.PanelLeft.Controls.Add(this.style_self);
            this.PanelLeft.Location = new System.Drawing.Point(-1, 25);
            this.PanelLeft.Name = "PanelLeft";
            this.PanelLeft.Size = new System.Drawing.Size(40, 400);
            this.PanelLeft.TabIndex = 31;
            this.toolTip1.SetToolTip(this.PanelLeft, "在此处选择，图像的蒙版样式");
            this.PanelLeft.DragDrop += new System.Windows.Forms.DragEventHandler(this.PanelLeft_DragDrop);
            this.PanelLeft.DragEnter += new System.Windows.Forms.DragEventHandler(this.PanelLeft_DragEnter);
            // 
            // style_0
            // 
            this.style_0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.style_0.BackgroundImage = global::easyIconFun.Properties.Resources._512_1;
            this.style_0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.style_0.Image = global::easyIconFun.Properties.Resources._512_e;
            this.style_0.Location = new System.Drawing.Point(3, 3);
            this.style_0.Name = "style_0";
            this.style_0.Size = new System.Drawing.Size(30, 30);
            this.style_0.TabIndex = 0;
            this.toolTip1.SetToolTip(this.style_0, "原样式");
            this.style_0.UseVisualStyleBackColor = false;
            this.style_0.Click += new System.EventHandler(this.style_Click);
            // 
            // style_1
            // 
            this.style_1.BackgroundImage = global::easyIconFun.Properties.Resources._512_2;
            this.style_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_1.Location = new System.Drawing.Point(3, 39);
            this.style_1.Name = "style_1";
            this.style_1.Size = new System.Drawing.Size(30, 30);
            this.style_1.TabIndex = 1;
            this.toolTip1.SetToolTip(this.style_1, "样式2");
            this.style_1.UseVisualStyleBackColor = true;
            this.style_1.Click += new System.EventHandler(this.style_Click);
            // 
            // style_2
            // 
            this.style_2.BackgroundImage = global::easyIconFun.Properties.Resources._512_2_5;
            this.style_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_2.Location = new System.Drawing.Point(3, 75);
            this.style_2.Name = "style_2";
            this.style_2.Size = new System.Drawing.Size(30, 30);
            this.style_2.TabIndex = 2;
            this.toolTip1.SetToolTip(this.style_2, "样式2.5");
            this.style_2.UseVisualStyleBackColor = true;
            this.style_2.Click += new System.EventHandler(this.style_Click);
            // 
            // style_3
            // 
            this.style_3.BackgroundImage = global::easyIconFun.Properties.Resources._512_3;
            this.style_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_3.Location = new System.Drawing.Point(3, 111);
            this.style_3.Name = "style_3";
            this.style_3.Size = new System.Drawing.Size(30, 30);
            this.style_3.TabIndex = 3;
            this.toolTip1.SetToolTip(this.style_3, "样式3");
            this.style_3.UseVisualStyleBackColor = true;
            this.style_3.Click += new System.EventHandler(this.style_Click);
            // 
            // style_4
            // 
            this.style_4.BackgroundImage = global::easyIconFun.Properties.Resources._512_3_5;
            this.style_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_4.Location = new System.Drawing.Point(3, 147);
            this.style_4.Name = "style_4";
            this.style_4.Size = new System.Drawing.Size(30, 30);
            this.style_4.TabIndex = 4;
            this.toolTip1.SetToolTip(this.style_4, "样式3.5");
            this.style_4.UseVisualStyleBackColor = true;
            this.style_4.Click += new System.EventHandler(this.style_Click);
            // 
            // style_5
            // 
            this.style_5.BackgroundImage = global::easyIconFun.Properties.Resources._512_4;
            this.style_5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_5.Location = new System.Drawing.Point(3, 183);
            this.style_5.Name = "style_5";
            this.style_5.Size = new System.Drawing.Size(30, 30);
            this.style_5.TabIndex = 5;
            this.toolTip1.SetToolTip(this.style_5, "样式4");
            this.style_5.UseVisualStyleBackColor = true;
            this.style_5.Click += new System.EventHandler(this.style_Click);
            // 
            // style_6
            // 
            this.style_6.BackgroundImage = global::easyIconFun.Properties.Resources._512_5;
            this.style_6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_6.Location = new System.Drawing.Point(3, 219);
            this.style_6.Name = "style_6";
            this.style_6.Size = new System.Drawing.Size(30, 30);
            this.style_6.TabIndex = 6;
            this.toolTip1.SetToolTip(this.style_6, "样式5");
            this.style_6.UseVisualStyleBackColor = true;
            this.style_6.Click += new System.EventHandler(this.style_Click);
            // 
            // style_7
            // 
            this.style_7.BackgroundImage = global::easyIconFun.Properties.Resources._512_6;
            this.style_7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_7.Location = new System.Drawing.Point(3, 255);
            this.style_7.Name = "style_7";
            this.style_7.Size = new System.Drawing.Size(30, 30);
            this.style_7.TabIndex = 7;
            this.toolTip1.SetToolTip(this.style_7, "样式6");
            this.style_7.UseVisualStyleBackColor = true;
            this.style_7.Click += new System.EventHandler(this.style_Click);
            // 
            // style_8
            // 
            this.style_8.BackgroundImage = global::easyIconFun.Properties.Resources._512_7;
            this.style_8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_8.Location = new System.Drawing.Point(3, 291);
            this.style_8.Name = "style_8";
            this.style_8.Size = new System.Drawing.Size(30, 30);
            this.style_8.TabIndex = 8;
            this.toolTip1.SetToolTip(this.style_8, "样式7");
            this.style_8.UseVisualStyleBackColor = true;
            this.style_8.Click += new System.EventHandler(this.style_Click);
            // 
            // style_9
            // 
            this.style_9.BackgroundImage = global::easyIconFun.Properties.Resources._512_8;
            this.style_9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_9.Location = new System.Drawing.Point(3, 327);
            this.style_9.Name = "style_9";
            this.style_9.Size = new System.Drawing.Size(30, 30);
            this.style_9.TabIndex = 9;
            this.toolTip1.SetToolTip(this.style_9, "样式8");
            this.style_9.UseVisualStyleBackColor = true;
            this.style_9.Click += new System.EventHandler(this.style_Click);
            // 
            // style_self
            // 
            this.style_self.BackgroundImage = global::easyIconFun.Properties.Resources.cocos;
            this.style_self.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.style_self.Location = new System.Drawing.Point(3, 363);
            this.style_self.Name = "style_self";
            this.style_self.Size = new System.Drawing.Size(30, 30);
            this.style_self.TabIndex = 10;
            this.toolTip1.SetToolTip(this.style_self, "自定义\r\n可以拖动任意png或icon图像至此，添加自定义样式\r\n（添加的图像，需包含透明度信息）\r\n");
            this.style_self.UseVisualStyleBackColor = true;
            this.style_self.Click += new System.EventHandler(this.style_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.panelTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTop.Controls.Add(this.mini);
            this.panelTop.Controls.Add(this.close);
            this.panelTop.Controls.Add(this.FormIcon);
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(641, 50);
            this.panelTop.TabIndex = 32;
            this.panelTop.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panelTop_MouseDown);
            // 
            // mini
            // 
            this.mini.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.mini.BackgroundImage = global::easyIconFun.Properties.Resources.minimize;
            this.mini.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.mini.Location = new System.Drawing.Point(562, -1);
            this.mini.Name = "mini";
            this.mini.Size = new System.Drawing.Size(32, 27);
            this.mini.TabIndex = 2;
            this.mini.UseVisualStyleBackColor = true;
            this.mini.Click += new System.EventHandler(this.mini_Click);
            // 
            // close
            // 
            this.close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close.BackgroundImage = global::easyIconFun.Properties.Resources.close;
            this.close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.close.Location = new System.Drawing.Point(593, -1);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(40, 27);
            this.close.TabIndex = 1;
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // FormIcon
            // 
            this.FormIcon.Image = global::easyIconFun.Properties.Resources.easyIcon;
            this.FormIcon.Location = new System.Drawing.Point(0, 3);
            this.FormIcon.Name = "FormIcon";
            this.FormIcon.Size = new System.Drawing.Size(188, 44);
            this.FormIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FormIcon.TabIndex = 0;
            this.FormIcon.TabStop = false;
            this.toolTip1.SetToolTip(this.FormIcon, "软件主页，下载最新版本");
            this.FormIcon.Click += new System.EventHandler(this.FormIcon_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // mainForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ClientSize = new System.Drawing.Size(641, 496);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelBody);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            //this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Icon = global::easyIconFun.Properties.Resources.formIcon;
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "easy Icon";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.mainForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.mainForm_DragEnter);
            this.panelMain.ResumeLayout(false);
            this.contextMenu_curExport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMain)).EndInit();
            this.menuStrip_main.ResumeLayout(false);
            this.menuStrip_main.PerformLayout();
            this.panelBody.ResumeLayout(false);
            this.panelBody.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.panelRightT.ResumeLayout(false);
            this.panelRightT.PerformLayout();
            this.contextMenu_ExportAll.ResumeLayout(false);
            this.panelRightB.ResumeLayout(false);
            this.panelRightB.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.contextMenu_Size.ResumeLayout(false);
            this.PanelLeft.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FormIcon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.PictureBox pictureBoxMain;
        private System.Windows.Forms.MenuStrip menuStrip_main;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Export;
        private System.Windows.Forms.Panel panelBody;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.PictureBox FormIcon;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button mini;
        private System.Windows.Forms.FlowLayoutPanel PanelLeft;
        private System.Windows.Forms.Button style_0;
        private System.Windows.Forms.Button style_1;
        private System.Windows.Forms.Button style_2;
        private System.Windows.Forms.Button style_3;
        private System.Windows.Forms.Button style_4;
        private System.Windows.Forms.Button style_5;
        private System.Windows.Forms.Button style_6;
        private System.Windows.Forms.Button style_7;
        private System.Windows.Forms.Button style_8;
        private System.Windows.Forms.Button style_9;
        private System.Windows.Forms.ToolStripMenuItem 帮助HToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_savePng;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveIcon;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveJpg;
        private System.Windows.Forms.Panel panelRightB;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_wikiInfo;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_pollCode;
        private System.Windows.Forms.Panel panelRightT;
        private System.Windows.Forms.Label labelFile;
        private System.Windows.Forms.CheckBox checkBoxAllFile;
        private System.Windows.Forms.CheckedListBox ListBox_Name;
        private System.Windows.Forms.CheckBox checkBoxAllSize;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_newSize;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_height;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox_width;
        private System.Windows.Forms.CheckedListBox ListBox_Size;
        private System.Windows.Forms.Label labelSize;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel StatusSizeLabel;
        private System.Windows.Forms.ToolStripStatusLabel StatusSize;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel StatusTipInfo;
        private System.Windows.Forms.ContextMenuStrip contextMenu_Size;
        private System.Windows.Forms.ToolStripMenuItem MenuItem2;
        private System.Windows.Forms.ToolStripSeparator MenuItem_split1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem4;
        private System.Windows.Forms.ToolStripMenuItem MenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MenuItem3;
        private System.Windows.Forms.ToolStripMenuItem MenuItem0;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Button style_self;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_setting;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Center;
        private System.Windows.Forms.ToolStripSeparator MenuItem_set_split;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_Dir;
        private System.Windows.Forms.ContextMenuStrip contextMenu_curExport;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveCurPng;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveCurIcon;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveCurJpg;
        private System.Windows.Forms.ToolStripSeparator MenuItem_cur_split;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_preview;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ContextMenuStrip contextMenu_ExportAll;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_savePngAll;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveIconAll;
        private System.Windows.Forms.ToolStripMenuItem MenuItem_saveJpgAll;
    }
}

