﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SciPay
{
    /// <summary>
    /// 支付示例： PayForm.Pay(Decodex105(0), Decodex105(1), Decodex105(2), Decodex105(3), Decodex105(3), Decodex105(3), PayResult);
    /// private void PayResult(string param)
    /// {
    ///     MessageBox.Show(Decodex105(4) + param);
    /// }
    /// </summary>
    public partial class PayForm : Form
    {
        private static string StringDatas107 = "oiihkkofkojkoeljijoilnkpoelllgofjainohkhladb$oiihkkofkojkoeljijofjfigofjdibofjainohkhladb$dacodadb$$ogjekpoelljiohlljdogjojmdk$fdgfhggfhcffhcgm$hdgpgghe$hahcgpgehfgdhe$gngpgogfhj$gngbgdgigjgoedgpgegf$gfhihe$gdgbgmgm$cacnca$ofloifogjekpoelljiojihjbojkcjnoplmjk$ofifid$dp$fefjfaefdnfahcgfephcgegfhc$cg$fcgfhdhfgmhe$fefjfaefdnfdgigphhfahcgfephcgegfhc$hahcgfephcgegfhcejgedn$fefjfaefdnephcgegfhcfcgfhdhfgmhe$gjhdfdhfgdgdgfhdhd$hehchfgf$gihehehadkcpcp$cphagbghgfhdcphagbhjcogbhdhahi$ogjmlkofjjkiohkaibdb$gfgbhdhjejgdgpgooilnkpoelllg$ogldkiofigimdacodadbofifid$ofkeihogldkioelpkbogibkp$gngbgdgigjgoedgpgegfdn$hdgpgghedn$hahcgpgehfgdhedn$gngpgogfhjdn$gfhihedn";
        private static string[] StringDatas107A = null;
        
        private static string Decodex105(int index108)
        {
            if (StringDatas107A == null) StringDatas107A = StringDatas107.Split((char)(',' - 8));    // '$'
            string data = StringDatas107A[index108];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        /// <summary>
        /// 调用支付
        /// </summary>
        /// <param name=Decodex105(5)>计费服务器Url</param>
        /// <param name=Decodex105(6)>软件名称</param>
        /// <param name=Decodex105(7)>商品名称</param>
        /// <param name=Decodex105(8)>金额</param>
        /// <param name=Decodex105(9)>机器码</param>
        /// <param name=Decodex105(10)>拓展参数</param>
        /// <param name=Decodex105(11)>支付结果回调</param>
        public static void Pay(string soft, string product, string money, string SeverUrl = "", string machinCode = "", string ext = "", PayCallBack call = null)
        {
            PayParam param = new PayParam(soft, product, money, SeverUrl, machinCode, ext);
            PayForm payForm = new PayForm(param, call);
            payForm.Text = product + Decodex105(12) + Decodex105(13) + money + Decodex105(14);

            //payForm.Show();
            payForm.ShowDialog();
        }

        /// <summary>
        /// 预下单,获取订单号
        /// </summary>
        public static string PreOrder(PayParam param)
        {
            string orderUrl = param.SeverUrl + Decodex105(15) + Decodex105(16) + Decodex105(17) + param.ToString();

            string data = WebTool.getWebData(orderUrl);
            string orderId = WebTool.getNodeData(data, Decodex105(18), false).Trim();
            return orderId;
        }

        /// <summary>
        /// 获取预下单展示Url
        /// </summary>
        public static string ShowPreOrderUrl(string SeverUrl, string preOrderId)
        {
            string url = SeverUrl + Decodex105(15) + Decodex105(19) + Decodex105(17) + Decodex105(20) + preOrderId;
            return url;
        }

        /// <summary>
        /// 查询订单支付结果
        /// </summary>
        public static string OrderResult(PayParam param, string preOrderId)
        {
            string url = param.SeverUrl + Decodex105(15) + Decodex105(21) + Decodex105(17) + Decodex105(20) + preOrderId;
            string paramStr = param.ToString();

            string data = WebTool.getWebData(url);
            string result = WebTool.getNodeData(data, Decodex105(18), false).Trim();

            // 使用创建订单时的参数信息，解密查询结果
            if (paramStr != null && !paramStr.Equals(Decodex105(3)))
            {
                result = Locker.Decrypt(result, preOrderId + paramStr);
            }

            return result;
        }

        //--------------


        PayParam param;         // 支付参数信息

        public delegate void PayCallBack(string param);
        PayCallBack call = null;   // 支付回调处理逻辑


        public PayForm(PayParam param, PayCallBack call)
        {
            InitializeComponent();
            init(param, call);
        }

        public PayForm(string soft, string product, string money, string SeverUrl = "", string machinCode = "", string ext = "", PayCallBack call = null)
        {
            InitializeComponent();
            PayParam param = new PayParam(soft, product, money, SeverUrl, machinCode, ext);
            init(param, call);
        }

        private void init(PayParam param, PayCallBack call)
        {
            this.param = param;
            this.call = call;

            timerRefresh_Tick(null, null);
        }

        string orderId = Decodex105(3);
        private void timerRefresh_Tick(object sender, EventArgs e)
        {
            if (orderId.Equals(Decodex105(3)))
            {
                orderId = PreOrder(param);                      // 1、下单，获取订单号

                string url = ShowPreOrderUrl(param.SeverUrl, orderId);
                contentWebBrowser.Navigate(url);                // 2、显示二维码支付页面
            }
            else
            {
                string result = OrderResult(param, orderId);    // 3、查询支付结果
                string isSuccess = WebTool.getNodeData(result, Decodex105(22), false).ToLower();
                if (isSuccess.Equals(Decodex105(23)))
                {
                    timerRefresh.Enabled = false;
                    if (call != null) call(result);
                    this.Close();
                }
            }
        }
    }

    /// <summary>
    /// 支付参数信息
    /// </summary>
    public class PayParam
    {
        private static string StringDatas107 = "oiihkkofkojkoeljijoilnkpoelllgofjainohkhladb$oiihkkofkojkoeljijofjfigofjdibofjainohkhladb$dacodadb$$ogjekpoelljiohlljdogjojmdk$fdgfhggfhcffhcgm$hdgpgghe$hahcgpgehfgdhe$gngpgogfhj$gngbgdgigjgoedgpgegf$gfhihe$gdgbgmgm$cacnca$ofloifogjekpoelljiojihjbojkcjnoplmjk$ofifid$dp$fefjfaefdnfahcgfephcgegfhc$cg$fcgfhdhfgmhe$fefjfaefdnfdgigphhfahcgfephcgegfhc$hahcgfephcgegfhcejgedn$fefjfaefdnephcgegfhcfcgfhdhfgmhe$gjhdfdhfgdgdgfhdhd$hehchfgf$gihehehadkcpcp$cphagbghgfhdcphagbhjcogbhdhahi$ogjmlkofjjkiohkaibdb$gfgbhdhjejgdgpgooilnkpoelllg$ogldkiofigimdacodadbofifid$ofkeihogldkioelpkbogibkp$gngbgdgigjgoedgpgegfdn$hdgpgghedn$hahcgpgehfgdhedn$gngpgogfhjdn$gfhihedn";
        private static string[] StringDatas107A = null;
        
        private static string Decodex105(int index108)
        {
            if (StringDatas107A == null) StringDatas107A = StringDatas107.Split((char)(',' - 8));    // '$'
            string data = StringDatas107A[index108];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        //public string SeverUrl = Decodex105(24) + Register.QrPayServerAddress + Decodex105(25);
        public string SeverUrl = Decodex105(3);

        public string machinCode = Decodex105(26);
        public string soft = Decodex105(27);
        public string product = Decodex105(28);
        public string money = Decodex105(2);
        public string ext = Decodex105(29);

        public PayParam(string soft, string product, string money, string SeverUrl = "", string machinCode = "", string ext = "")
        {
            if (SeverUrl != null && !SeverUrl.Equals(Decodex105(3))) this.SeverUrl = SeverUrl;
            this.machinCode = machinCode;
            this.soft = soft;
            this.product = product;
            this.money = money;
            this.ext = ext;
        }

        /// <summary>
        /// 拼接为参数串
        /// </summary>
        public string ToString(/*string soft, string product, string money, string machinCode = Decodex105(3), string ext = Decodex105(3)*/)
        {
            return Decodex105(30) + machinCode + Decodex105(17) + Decodex105(31) + soft + Decodex105(17) + Decodex105(32) + product + Decodex105(17) + Decodex105(33) + money + Decodex105(17) + Decodex105(34) + ext;
        }

    }
}

