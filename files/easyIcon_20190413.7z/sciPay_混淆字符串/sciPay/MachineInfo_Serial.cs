﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace SciPay
{

    //在项目-》添加引用....里面引用System.Management  
    public class MachineInfo_Serial
    {
        private static string StringDatas106 = "fdgfgmgfgdhecackcaeghcgpgncafhgjgodddcfpfahcgpgdgfhdhdgphc$$fahcgpgdgfhdhdgphcejge$fdefemefedfecackcaegfcepencafhgjgodddcfpfagihjhdgjgdgbgmengfgegjgb$fdgfhcgjgbgmeohfgngcgfhc$fdgfgmgfgdhecackcaeghcgpgncafhgjgodddcfpecejepfd$fdgfgmgfgdhecackcagghcgpgncafhgjgodddcfpecgbhdgfecgpgbhcge$fdefemefedfecackcaegfcepencafhgjgodddcfpeogfhehhgphcglebgegbhahegfhcedgpgogggjghhfhcgbhegjgpgo$ejfaefgogbgcgmgfge$fehchfgf$engbgdebgegehcgfhdhd$ecegefecegecegegdadadadddadgebdj$feefebdfdfebddfbdcfadhfhelfc$co$egenegfeegfhdbedeodbdcdjdgdgdddbecdadfdjef$fadhfhelfcdddadgebdjdbecdadfdjef$fdedejenefeoedef$fdedejencnefeoedefcnefebfdfjcnejedepeo$fifcffencnemfjelfdcndefcdcfacnfbfadgei$fdedejencnefeoedefcnfcefehefcneeejfefd$cn$ecegefeccnegecegegcndadadaddcndadgebdj";
        private static string[] StringDatas106A = null;
        
        private static string Decoded104(int index107)
        {
            if (StringDatas106A == null) StringDatas106A = StringDatas106.Split((char)(',' - 8));    // '$'
            string data = StringDatas106A[index107];
            data = codero.DecodeAlphabet(data);
            return data;
        }



        # region 获取计算机硬件信息

        /// <summary>
        /// 获取CPU序列号  
        /// </summary>
        public static string GetCPUSerialNumber()
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(Decoded104(0));
                string sCPUSerialNumber = Decoded104(1);
                foreach (ManagementObject mo in searcher.Get())
                {
                    sCPUSerialNumber = mo[Decoded104(2)].ToString().Trim();
                }
                return sCPUSerialNumber;
            }
            catch
            {
                return Decoded104(1);
            }
        }

        /// <summary>
        /// 获取硬盘序列号  
        /// </summary>
        public static string GetHardDiskSerialNumber()
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(Decoded104(3));
                string sHardDiskSerialNumber = Decoded104(1);
                foreach (ManagementObject mo in searcher.Get())
                {
                    sHardDiskSerialNumber = mo[Decoded104(4)].ToString().Trim();
                    break;
                }
                return sHardDiskSerialNumber;
            }
            catch
            {
                return Decoded104(1);
            }
        }

        /// <summary>  
        /// 获取主板序列号  
        /// </summary>
        public static string GetBIOSSerialNumber()
        {
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(Decoded104(5));
                string sBIOSSerialNumber = Decoded104(1);
                foreach (ManagementObject mo in searcher.Get())
                {
                    sBIOSSerialNumber = mo[Decoded104(4)].ToString().Trim();
                }
                return sBIOSSerialNumber;
            }
            catch
            {
                return Decoded104(1);
            }
        }
        /// <summary>  
        /// 主板编号  
        /// </summary>  
        public static string GetBoardID()
        {
            string st = Decoded104(1);
            ManagementObjectSearcher mos = new ManagementObjectSearcher(Decoded104(6));
            foreach (ManagementObject mo in mos.Get())
            {
                st = mo[Decoded104(4)].ToString();
            }
            return st;
        }  
        /// <summary>  
        /// 获取本机的MAC;  
        /// </summary>  
        public static string GetLocalMac()
        {
            string mac = null;
            ManagementObjectSearcher query = new ManagementObjectSearcher(Decoded104(7));
            ManagementObjectCollection queryCollection = query.Get();
            foreach (ManagementObject mo in queryCollection)
            {
                if (mo[Decoded104(8)].ToString() == Decoded104(9))
                    mac = mo[Decoded104(10)].ToString();
            }
            return (mac);
        }


        /// <summary>
        /// 获取计算机名
        /// </summary>
        public static string ComputerName()
        {
            return Environment.MachineName;
        }

        /// <summary>
        /// 操作系统的登录用户名
        /// </summary>
        public static string UserName()
        {
            return Environment.UserName;
        }

        # endregion

        //===============================================

        #region 自定义机器码、注册码生成算法


        private static string machineSerial;

        /// <summary>
        /// 根据硬件信息，生成机器码
        /// </summary>
        public static string MachineSerial()
        {
            if (machineSerial != null) return machineSerial;

            string CPUSerial = MachineInfo_Serial.GetCPUSerialNumber();            // Decodex104(11)
            string HardDiskSerial = MachineInfo_Serial.GetHardDiskSerialNumber();  // Decodex104(12)
            string BoardID = MachineInfo_Serial.GetBoardID().Replace(Decoded104(13), Decoded104(1));     // Decodex104(14)

            machineSerial = getTails(HardDiskSerial, 5) + getTails(CPUSerial, 5) + getTails(BoardID, 6); //Decodex104(15)
            machineSerial = format(machineSerial);

            return machineSerial;
        }


        private static string softSerial;

        /// <summary>
        /// 根据硬件机器码，生成软件码
        /// </summary>
        public static string SoftSerial(string SoftName)
        {
            if (softSerial != null) return softSerial;

            string serial = MachineSerial();

            string Key = format(Decoded104(16) + SoftName); // Decodex104(17)
            serial = lockLogic(serial, Key);            // 软件附加码 // Decodex104(18)

            softSerial = serial;
            return serial;
        }

        private static string regSerial;

        /// <summary>
        /// 根据软件码生成注册码
        /// </summary>
        public static string RegSerial(string SoftName)
        {
            if (regSerial != null) return regSerial;
            regSerial = lockLogic(SoftSerial(SoftName), Decoded104(19));
            return regSerial;
        }

        /// <summary>
        /// 获取Data尾部len长度的串
        /// </summary>
        private static string getTails(string Data, int len)
        {
            return Data.Substring(Data.Length - len, len);
        }

        /// <summary>
        /// 对字符串Data用字符串Key进行加密
        /// </summary>
        private static string lockLogic(string Data, string Key)
        {
            Data = Data.Replace(Decoded104(20), Decoded104(1)).ToUpper();
            Key = Key.Replace(Decoded104(20), Decoded104(1)).ToUpper();

            char[] data = Data.ToCharArray();
            char[] key = Key.ToCharArray();

            string tmp = Decoded104(1);
            for (int i = 0; i < data.Length; i++)
            {
                tmp += AlpahLock(data[i], key[i % key.Length]);
            }
            return format(tmp);
        }

        /// <summary>
        /// 对字符C用K加密，转化为A-Z、0-9对应的字符
        /// </summary>
        private static char AlpahLock(char C, char K)
        {
            int n = (C + K) % 35;
            if (n < 26) return (char)(n + 'A'); // 0-25映射到 A-Z
            else return (char)(n - 26 + '1');   // 26-34映射到 1-9
        }

        /// <summary>
        /// 规整化字符串Decodex104(11)为Decodex104(21)
        /// </summary>
        public static string format(string Data)
        {
            Data = Data.Replace(Decoded104(20), Decoded104(1)).ToUpper();
            char[] data = Data.ToCharArray();

            string tmp = Decoded104(1);
            for (int i = 0; i < data.Length; i++)
            {
                tmp += data[i];
                tmp += (((i + 1) % 4 == 0 && i < data.Length - 1) ? Decoded104(20) : Decoded104(1));
            }
            return tmp;
        }

        #endregion

    }
}

