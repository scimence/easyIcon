﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SciPay
{
    public class codero
    {
        /// <summary> 
        /// 解析字母字符串
        /// </summary>
        public static string DecodeAlphabet(string data)
        {
            byte[] B = new byte[data.Length / 2];
            char[] C = data.ToCharArray();
            for (int i = 0; i < C.Length; i += 2)
            {
                byte b = ToByte(C[i], C[i + 1]);
                B[i / 2] = b;
            }
            return System.Text.Encoding.UTF8.GetString(B);
        }
        
        /// <summary>  
        /// 每两个字母还原为一个字节
        /// </summary>
        private static byte ToByte(char a1, char a2)
        {
            return (byte)((a1 - 'a') * 16 + (a2 - 'a'));
        }
    }
        


    public class RegistryTool
    {
        private static string StringDatas110 = "engjgdhcgphdgpgghefmfhgjgogegphhhdfmedhfhchcgfgohefggfhchdgjgpgofmfchfgo$fbfb$eddkfmhhgjgogegphhhdfmhdhjhdhegfgndddcfmfbfbcogfhigf$fdgdgjgngfgogdgffmefgngbgjgmfmfdgfhe$eieleffjfpedfffcfcefeofefpfffdeffcfdgpgghehhgbhcgf$fdgpgghehhgbhcgf$fdgpgghehhgbhcgffm$";
        private static string[] StringDatas110A = null;
        
        private static string Decodex108(int index111)
        {
            if (StringDatas110A == null) StringDatas110A = StringDatas110.Split((char)(',' - 8));    // '$'
            string data = StringDatas110A[index111];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        //=======================================================
        // 注册表操作
        //=======================================================

        # region 注册表操作
        //设置软件开机启动项： RegistrySave(Decodex108(0), Decodex108(1), Decodex108(2));  

        /// <summary>
        /// 记录键值数据到注册表subkey = Decodex108(3);
        /// </summary>
        public static void RegistrySave(string subkey, string name, object value)
        {
            //设置一个具有写权限的键 访问键注册表Decodex108(4)
            Microsoft.Win32.RegistryKey keyCur = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(5), true);
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);
            if (keySet == null) keySet = keyCur.CreateSubKey(subkey);   //键不存在时创建

            keySet.SetValue(name, value);   //保存键值数据
        }

        /// <summary>
        /// 获取注册表subkey下键name的字符串值
        /// <summary>
        public static string RegistryStrValue(string subkey, string name)
        {
            object value = RegistryValue(subkey, name);
            return value == null ? Decodex108(7) : value.ToString();
        }

        /// <summary>
        /// 获取注册表subkey下键name的值
        /// <summary>
        public static object RegistryValue(string subkey, string name)
        {
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);
            return (keySet == null ? null : keySet.GetValue(name, null));
        }

        /// <summary>
        /// 判断注册表是否含有子键subkey
        /// <summary>
        public static bool RegistryCotains(string subkey)
        {
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);
            return (keySet != null);
        }

        /// <summary>
        /// 判断注册表subkey下是否含有name键值信息
        /// <summary>
        public static bool RegistryCotains(string subkey, string name)
        {
            //设置一个具有写权限的键 访问键注册表Decodex108(4)
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);

            if (keySet == null) return false;
            else return keySet.GetValueNames().Contains<string>(name);
        }

        /// <summary>
        /// 删除注册表subkey信息
        /// <summary>
        public static void RegistryRemove(string subkey)
        {
            //设置一个具有写权限的键 访问键注册表Decodex108(4)
            Microsoft.Win32.RegistryKey keyCur = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(5), true);
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);

            if (keySet != null) keyCur.DeleteSubKeyTree(subkey);      //删除注册表信息
        }

        /// <summary>
        /// 删除注册表subkey下的name键值信息
        /// <summary>
        public static void RegistryRemove(string subkey, string name)
        {
            //设置一个具有写权限的键 访问键注册表Decodex108(4)
            Microsoft.Win32.RegistryKey keySet = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Decodex108(6) + subkey, true);
            if (keySet != null) keySet.DeleteValue(name, false);
        }

        # endregion

    }
}

