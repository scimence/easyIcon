﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SciPay
{
    /// <summary>
    /// 从指定网址获取配置信息：
    /// Configer.Instance.Get(Decodex101(0))
    /// 
    /// serverInfo.txt：
    /// QrPayServerAddress(127.0.0.1:7002)QrPayServerAddress
    /// ApplicationTest(127.0.0.1:7001)ApplicationTest
    /// </summary>
    public class WebConfiger
    {
        private static string StringDatas103 = "fbhcfagbhjfdgfhchggfhcebgegehcgfhdhd$gihehehahddkcpcphdgdgjgngfgogdgfcoghgjhegfgfcogjgpcpgdgpgogggjghcpgggjgmgfhdcpgdgpgogggjghcohehihe$hfhcgm$$glgfhj$dgdacodcdadfcodbdidfcodbdgdidkdidadadc";
        private static string[] StringDatas103A = null;
        
        private static string Decodey101(int index104)
        {
            if (StringDatas103A == null) StringDatas103A = StringDatas103.Split((char)(',' - 8));    // '$'
            string data = StringDatas103A[index104];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        //public static WebConfiger Instance = new WebConfiger();

        private string url = Decodey101(1);    // 配置文件文件网址

        /// <summary>
        /// 获取指定网址的配置信息
        /// </summary>
        /// <param name=Decodex101(2)></param>
        public WebConfiger(string url)
        {
            if(url != null && !url.Equals(Decodey101(3))) this.url = url;
        }

        /// <summary>
        /// 获取key对应的配置信息
        /// </summary>
        /// <param name=Decodex101(4)></param>
        /// <returns></returns>
        public string Get(string key)
        {
            if (url == null || url.Equals(Decodey101(3))) return Decodey101(3);
            if (key == null || key.Equals(Decodey101(3))) return Decodey101(3);

            string value = WebTool.getWebData(url, key);
            if (key.Equals(Decodey101(0)) && value.Equals(Decodey101(3))) 
                value = Decodey101(5);

            return value;
        }
    }
}

