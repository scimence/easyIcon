﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SciPay
{
    // 示例：scimence( Name1(6JSO-F2CM-4LQJ-JN8P) )scimence
    // string url = Decodex109(0);
    // 
    // string data = getWebData(url);
    // string str1 = getNodeData(data, Decodex109(1), false);
    // string str2 = getNodeData(str1, Decodex109(2), true);

    /// <summary>
    /// 此类用于获取，在网络文件中的配置信息
    /// </summary>
    public class WebTool
    {
        private static string StringDatas111 = "gihehehahddkcpcpghgjhecogphdgdgigjgogbcogogfhecphdgdgjgngfgogdgfcpgfgbhdhjejgdgpgocphhgjglgjhdcpepgogmgjgogffdgfhcgjgbgm$hdgdgjgngfgogdgf$eogbgngfdb$hfhcgm$$gegbhegb$gogpgegfeogbgngf$gggjgogbgmeogpgegf$ci$cj";
        private static string[] StringDatas111A = null;
        
        private static string Decodex109(int index112)
        {
            if (StringDatas111A == null) StringDatas111A = StringDatas111.Split((char)(',' - 8));    // '$'
            string data = StringDatas111A[index112];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        #region 网络数据的读取

        /// <summary>
        /// 获取url页面，key(**value**)中的value数据
        /// </summary>
        public static string getWebData(string url, string key)
        {
            string data = getWebData(url);
            string str1 = getNodeData(data, key, true);

            return str1;
        }

        /// <summary>
        /// 从给定的网址中获取数据
        /// </summary>
        /// <param name=Decodex109(3)></param>
        /// <returns></returns>
        public static string getWebData(string url)
        {
            try
            {
                System.Net.WebClient client = new System.Net.WebClient();
                client.Encoding = System.Text.Encoding.Default;
                string data = client.DownloadString(url);
                return data;
            }
            catch (Exception) { return Decodex109(4); }
        }

        #endregion

        
        //p>scimence(&#x000A;NeedToRegister(false)NeedToRegister&#x000A;RegisterPrice(1)RegisterPrice&#x000A;)scimence</p>&#x000A;</div>
        /// <summary>
        /// 从自定义格式的数据data中，获取nodeName对应的节点数据
        /// 
        /// NeedToRegister(false)NeedToRegister     // finalNode = false;
        /// RegisterPrice(1)                        // finalNode = true;
        /// </summary>
        /// <param name=Decodex109(5)>待解析的数据</param>
        /// <param name=Decodex109(6)>节点名称</param>
        /// <param name=Decodex109(7)>是否为叶节点</param>
        /// <returns></returns>
        public static string getNodeData(string data, string nodeName, bool finalNode)
        {
            if (!data.Contains(nodeName)) return Decodex109(4);

            try
            {
                string S = nodeName + Decodex109(8), E = Decodex109(9) + (finalNode ? Decodex109(4) : nodeName);
                int indexS = data.IndexOf(S) + S.Length;
                int indexE = data.IndexOf(E, indexS);

                return data.Substring(indexS, indexE - indexS);
            }
            catch (Exception) { return data; }
        }
    }
}

