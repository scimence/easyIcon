﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace SciPay
{
    /// <summary>
    /// RegisterTool.CheckRegLogic(SoftName, AuthorName); 检测注册逻辑是否执行完成。
    /// if(RegisterTool.Instance != null) RegisterTool.Instance.RegLogic_Online(是否已注册回调处理逻辑)
    /// </summary>
    public class RegisterTool
    {
        private static string StringDatas109 = "fdgpggheeogbgngf$ebhfhegigphceogbgngf$gihehehahddkcpcphdgdgjgngfgogdgfcoghgjhegfgfcogjgpcpgdgpgogggjghcpgggjgmgfhdcpgdgpgogggjghcohehihe$fbhcfagbhjfdgfhchggfhcebgegehcgfhdhd$ogickiojjmiaoikgibofifiiofkoimogiijaogldkiofigimcmogijinoiidlnoelnlpohjekiogknkeofikjpoiidln$oilnkpoelllgogldkiofigim$dbdcdhcodacodacodb$oilnkpoelllgdb$ogjhkaofjain$hjgfhd$gogp$gfgoge$gdgpgegf$$da$gghcgfgffegjgngfhd$hdhegbhchefegjgngfhd$gihehehadkcpcp$cphagbghgfhdcphdgpgghegjgogggpcogbhdhahidpfefjfaefdnfdgfgmgfgdhecghdgpggheeogbgngfdn$cgglgfhjdnhahcgjgdgf$hahcgjgdgf$dbdacodada$gnhdgh$fdgpggheefhihe$engbgdgigjgogffdgpggheenhdgh$fm$fmfdgfhe$fdgfhcgjgbgm$ogibknofjgjmoplmimogickioflhlcogiijaofikjpogldkiofigimoplmiboplmiioflmicogknkfogldkiofigimoplmijanakanakofinldoelolpojihinoikdifohldllohlljpoplmimoeljjpogjhkaojjmiaofiginogkmkbogldkiofigimcoanakedgphahjhcgjghgihecamckjcacadcdadbdicafdgdgjgngfgogdgf$gngbgdgigjgoedgpgegf$hdgpgghe$gdgpgnhahfhegfhceogbgngf$hfhdgfhceogbgngf$gfhihe$gggbgmhdgf$hehchfgf$cphagbghgfhdcpgpgogmgjgogfhdgfhcgjgbgmcogbhdhahidpfefjfaefdnehgfhefcgfghfdgfhcgjgbgmcggngbgdgigjgoedgpgegfdn$cghdgpgghedn$cggdgpgnhahfhegfhceogbgngfdn$cghfhdgfhceogbgngfdn$cggfhihedn$cggdgphfgohegfhcdn$eleffj$cphagbghgfhdcpgpgogmgjgogfhdgfhcgjgbgmcogbhdhahidpfefjfaefdnehgfhefggbgmhfgfcgeleffjdn$cggngbgdgigjgoedgpgegfdn$cgglgfhjdnhcgfgdgpgngpgogeffhcgm$cgglgfhjdngmgjgoglffhcgm$cgglgfhjdngfhihe$fman$an$fmak$ak$fmaj$aj$fmgfgbhdhjejgdgpgofmfdgfhe$ohlnjbohlljmoeliinofipkpohjekioplmimogjhkaogldjfoiiolhofipjgoilnkpoelllgohiklgogiaiboelpkbogibkpanakoikplhofifiioilpjoogiokfohlnjbohlljmofjaiooplmimofiginoelnlpohjekiogknkeoflhkfofiflh$cphagbghgfhdcphagbhjcogbhdhahi$gbhfhegigphcci$cj$gjhdfdhfgdgdgfhdhd$ogibknofjgjmoplmimogickioflhlcogiijaofikjpogldkiofigimoplmiboplmiiofinldogjhlgogldkiofigimoplmij";
        private static string[] StringDatas109A = null;
        
        private static string Decodex107(int index110)
        {
            if (StringDatas109A == null) StringDatas109A = StringDatas109.Split((char)(',' - 8));    // '$'
            string data = StringDatas109A[index110];
            data = codero.DecodeAlphabet(data);
            return data;
        }


        public static RegisterTool Instance = null;

        /// <summary>
        /// 检测注册逻辑是否执行完成
        /// </summary>
        /// <param name=Decodex107(0)></param>
        /// <param name=Decodex107(1)></param>
        /// <returns></returns>
        public static bool CheckRegLogic(string SoftName, string AuthorName)
        {
            if (Instance == null)
            {
                string QrPayServerAddress = new WebConfiger(Decodex107(2)).Get(Decodex107(3));
                Instance = new RegisterTool(QrPayServerAddress, SoftName, AuthorName);
            }

            bool isRegUser = Instance.IsRegUser();
            if (!isRegUser)
            {
                DialogResult result = MessageBox.Show(Decodex107(4), Decodex107(5), MessageBoxButtons.OKCancel);
                if (result == DialogResult.OK) Instance.RegLogic();
            }

            return isRegUser;
        }

        //--------------------------

        public string QrPayServerAddress = Decodex107(6);   // Configer.Instance.Get(Decodex107(3));
        public string SoftName = Decodex107(7);                 // DependentFiles.GetNamespace(Assembly.GetEntryAssembly());
        public string AuthorName = Decodex107(8);                // 软件作者

        /// <summary>
        /// 是否需要注册回调处理逻辑 code=Decodex107(9)、Decodex107(10)、Decodex107(11)
        /// </summary>
        /// <param name=Decodex107(12)>Decodex107(9)、Decodex107(10)、Decodex107(11)</param>
        public delegate void NeedRegisterCallBack(string code);
        public NeedRegisterCallBack needRegCallBack;

        private Timer Timer_CheckOnlineRegister = null;

        /// <summary>
        /// 创建Register对象
        /// </summary>
        /// <param name=Decodex107(3)>Qr支付网址</param>
        /// <param name=Decodex107(0)>软件名称</param>
        public RegisterTool(string QrPayServerAddress, string SoftName, string AuthorName)
        {
            this.QrPayServerAddress = QrPayServerAddress;
            this.SoftName = SoftName;
            this.AuthorName = AuthorName;

            // 定时查询在线注册信息
            Timer_CheckOnlineRegister = new Timer();
            Timer_CheckOnlineRegister.Interval = 60000;
            Timer_CheckOnlineRegister.Enabled = true;
            Timer_CheckOnlineRegister.Tick += new System.EventHandler(Timer_CheckOnlineRegister_Tick);
        }

        // 定时器，用于首次打开界面时控制信息的延时载入
        private void Timer_CheckOnlineRegister_Tick(object sender, EventArgs e)
        {
            RegLogic_Online();    // 实时查询，在线注册逻辑
        }

        /// <summary>
        /// 根据网页控制开关，判定是否需要注册 
        /// 若软件的支付金额为0，则不需要注册
        /// </summary>
        /// <returns></returns>
        public bool needRegister()
        {
            string price = getPrice();
            if (price.Equals(Decodex107(13)) || !price.Equals(Decodex107(14)))
            {
                if (getStartTimes() <= getSoftFreeTimes()) return false;     // 小于10次启动次数，不需要注册
                else return true;
            }
            else return false;
        }

        int freeTimes = 0;
        private int getSoftFreeTimes()
        {
            if (freeTimes > 0) return freeTimes;

            try
            {
                string value = ExtInfo(Decodex107(15));
                if (value.Equals(Decodex107(13))) freeTimes = 15;
                else freeTimes = int.Parse(value);
            }
            catch (Exception)
            {
                freeTimes = 15;
            }

            return freeTimes;
        }

        private int startTimes = -1;
        /// <summary>
        /// 获取客户端的当前启动次数
        /// </summary>
        /// <returns></returns>
        private int getStartTimes()
        {
            if (startTimes == -1)
            {
                try
                {
                    string times = GetValue(Decodex107(16), MachineInfo_Serial.MachineSerial(), SoftName);
                    if (times.Equals(Decodex107(13))) startTimes = 0;
                    else startTimes = int.Parse(times);
                }
                catch (Exception)
                {
                    return 10000;
                }
            }
            return startTimes;
        }

        private string price = Decodex107(13);

        /// <summary>
        /// 获取软件的支付金额信息
        /// </summary>
        /// <returns></returns>
        public string getPrice()
        {
            //if (!price.Equals(Decodex107(13))) return price;
            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(18) + SoftName + Decodex107(19);
            string data = WebTool.getWebData(Url).Trim();
            if (!data.Equals(Decodex107(13)))
            {
                data = Locker.Decrypt(data, SoftName);  // 使用软件名称解密，加密的金额信息
                price = WebTool.getNodeData(data, Decodex107(20), false);
            }
            if (price.Equals(Decodex107(13))) price = Decodex107(21);

            return price;
        }
            
        /// <summary>
        /// 在线注册逻辑,自动检测是否已在线注册，若已经注册，则完成本地注册逻辑。
        /// 启动后首次，通过接口发送软件启动信息至服务器；
        /// 再次检测时，在查询本地注册信息之后，若未注册则在线查询。
        /// 通过needRegCallBack执行回调处理逻辑
        /// </summary>
        public void RegLogic_Online(NeedRegisterCallBack needRegCallBack = null)
        {
            if (needRegCallBack != null) this.needRegCallBack = needRegCallBack;    // 记录回调处理逻辑

            string onlineSerial = Decodex107(13);

            // 0、发送软件启动信息至服务器
            bool isFirst = isFirstGetOnlineSerial;
            if (isFirst)
            {
                // 获取序列号信息
                onlineSerial = GetOnlineSerial(MachineInfo_Serial.MachineSerial(), SoftName, MachineInfo_Serial.ComputerName(), MachineInfo_Serial.UserName(), Decodex107(13));

                // 显示软件msg信息
                string SoftExt = ExtInfo(Decodex107(22));
                showExtMessage(Decodex107(23), SoftExt);

                // 显示机器软件对应的msg信息
                string MachineSoftMsg = GetValue(Decodex107(22), MachineInfo_Serial.MachineSerial(), SoftName);
                showExtMessage(Decodex107(24), MachineSoftMsg);
            }

            if (!this.IsRegUser())      // 1、若本地未注册
            {
                if (!isFirst) onlineSerial = GetOnlineSerial(MachineInfo_Serial.MachineSerial(), SoftName, MachineInfo_Serial.ComputerName(), MachineInfo_Serial.UserName(), Decodex107(13));

                // 2、则查询是否已在线注册
                if (!onlineSerial.Equals(Decodex107(13)) && onlineSerial.Equals(MachineInfo_Serial.RegSerial(SoftName)))
                {
                   RegistryTool.RegistrySave(AuthorName + Decodex107(25) + SoftName + Decodex107(26), Decodex107(27), onlineSerial);
                    MessageBox.Show(Decodex107(28));
                }
            }
        }

        private bool isFirstGetOnlineSerial = true;

        /// <summary>
        /// 根据机器信息, 在线查询是否已注册码；
        /// TYPE=GetRegSerial&machinCode=XRUM-LYKS-4R2P-QP6H&soft=easyIcon&computerName=计算机名称&userName=用户名称&ext=拓展参数&counter=true
        /// </summary>
        /// <param name=Decodex107(29)></param>
        /// <param name=Decodex107(30)></param>
        /// <param name=Decodex107(31)></param>
        /// <param name=Decodex107(32)></param>
        /// <param name=Decodex107(33)></param>
        /// <returns></returns>
        public string GetOnlineSerial(string machinCode, string soft, string computerName = "", string userName = "", string ext = "")
        {
            string counter = Decodex107(34);
            if (isFirstGetOnlineSerial)
            {
                counter = Decodex107(35);
                isFirstGetOnlineSerial = false;
            }

            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(36) + machinCode + Decodex107(37) + soft + Decodex107(38) + computerName + Decodex107(39) + userName + Decodex107(40) + ext + Decodex107(41) + counter;
            string data = WebTool.getWebData(Url).Trim();

            return data;
        }


        /// <summary>
        /// 查询KEY列对应的数据信息
        /// </summary>
        /// <param name=Decodex107(42)>列名称</param>
        /// <param name=Decodex107(29)>机器码</param>
        /// <param name=Decodex107(30)>软件名称</param>
        /// <returns></returns>
        public string GetValue(string KEY, string machinCode, string soft)
        {
            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(43) + KEY + Decodex107(44) + machinCode + Decodex107(37) + soft;
            string data = WebTool.getWebData(Url).Trim();
            if (!data.Equals(Decodex107(13)))
            {
                data = Locker.Decrypt(data, machinCode + soft);
                data = WebTool.getNodeData(data, KEY, false);
            }

            return data;
        }

        private string recomondUrl = Decodex107(13);
        /// <summary>
        /// 获取软件的支付金额信息
        /// </summary>
        /// <returns></returns>
        public string RecommendUrl()
        {
            if (!recomondUrl.Equals(Decodex107(13))) return recomondUrl;

            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(18) + SoftName + Decodex107(45);
            string data = WebTool.getWebData(Url).Trim();
            recomondUrl = data;

            return data;
        }

        private string linkUrl = Decodex107(13);
        /// <summary>
        /// 获取软件的支付金额信息
        /// </summary>
        /// <returns></returns>
        public string LinkUrl()
        {
            if (!linkUrl.Equals(Decodex107(13))) return linkUrl;

            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(18) + SoftName + Decodex107(46);
            string data = WebTool.getWebData(Url).Trim();
            linkUrl = data;

            return data;
        }


        /// <summary>
        /// 获取获取ext附加参数中的信息
        /// </summary>
        /// <returns></returns>
        public string ExtInfo(string extKey)
        {
            string Url = Decodex107(17) + QrPayServerAddress + Decodex107(18) + SoftName + Decodex107(47);
            string data = WebTool.getWebData(Url).Trim();
            if (!data.Equals(Decodex107(13)))
            {
                data = Locker.Decrypt(data, SoftName);  // 使用软件名称解密，加密的金额信息
                price = WebTool.getNodeData(data, Decodex107(33), false);
            }
            string extValue = WebTool.getNodeData(data, extKey, false);

            return extValue;
        }

        /// <summary>
        /// 显示软件公告信息
        /// </summary>
        public void showExtMessage(string key, string msg)
        {
            //string msg = ExtInfo(Decodex107(22)).Replace(Decodex107(48), Decodex107(49)).Replace(Decodex107(50), Decodex107(51)).Replace(Decodex107(52), Decodex107(53));
            msg = msg.Replace("\\r", "\r").Replace("\\n", "\n").Replace("\\t", "\t");
            if (msg.Equals(Decodex107(13))) return;     // 若无公告信息，则返回
            else
            {
                bool contains = RegistryTool.RegistryCotains(AuthorName + Decodex107(25) + SoftName + Decodex107(26), key);
                if (contains)
                {
                    string preMsg = RegistryTool.RegistryStrValue(AuthorName + Decodex107(25) + SoftName + Decodex107(26), key);
                    if (!preMsg.Equals(Decodex107(13)) && preMsg.Equals(msg)) return;
                }
            }

            MessageBox.Show(msg);
            RegistryTool.RegistrySave(AuthorName + Decodex107(25) + SoftName + Decodex107(26), key, msg);
        }

        /// <summary>
        ///  从注册表载入信息，判断用户是否已经注册
        /// </summary>
        /// <returns></returns>
        public bool IsRegUser()
        {
            // 检测本地注册信息，
            // 若已经注册成功
            bool containsSerial = RegistryTool.RegistryCotains(AuthorName + Decodex107(25) + SoftName + Decodex107(26), Decodex107(27));
            //mainForm.F.RegistryRemove(AuthorName + Decodex107(54), Decodex107(27));
            if (containsSerial)
            {
                // 优先判断本地注册表数据
                string serial =RegistryTool.RegistryStrValue(AuthorName + Decodex107(25) + SoftName + Decodex107(26), Decodex107(27));
                if (!serial.Equals(Decodex107(13)) && serial.Equals(MachineInfo_Serial.RegSerial(SoftName)))
                {
                    if (Timer_CheckOnlineRegister.Enabled) Timer_CheckOnlineRegister.Enabled = false;   // 停止计时查询逻辑
                    if (this.needRegCallBack != null) this.needRegCallBack(Decodex107(11)); //4、若已注册，则执行结束逻辑
                    return true;
                }
            }

            // 若未注册，则弹出网络提示
            bool available = System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable();
            if (!available)
            {
                MessageBox.Show(Decodex107(55));
                Application.Exit(); // 自动退出应用
                return false;       // 网络未连接视作未注册用户
            }

            // 若未注册成功，在线检测是否需要注册
            bool isNeed = needRegister();
            if (this.needRegCallBack != null)   // 2、先检测是否需要注册
            {
                if (isNeed) this.needRegCallBack(Decodex107(9));
                else this.needRegCallBack(Decodex107(10));
            }

            return !isNeed; // 若不需要注册，则视作已注册用户
        }

        /// <summary>
        /// 调用注册逻辑
        /// </summary>
        public void RegLogic()
        {
            string price = getPrice();                              // 获取软件金额
            //string machinCode = MachineInfo.SoftSerial(SoftName);   // 获取当前的机器码
            string machinCode = MachineInfo_Serial.MachineSerial();        // 获取当前的机器码

            string SeverUrl = Decodex107(17) + this.QrPayServerAddress + Decodex107(56);
            PayForm.Pay(SoftName, Decodex107(5), price, SeverUrl, machinCode, Decodex107(57) + AuthorName + Decodex107(58), PayResult);
        }

        // 支付结果处理逻辑
        private void PayResult(string param)
        {
            string isSuccess = WebTool.getNodeData(param, Decodex107(59), false).ToLower();
            if (isSuccess.Equals(Decodex107(35)))
            {
                string serial = MachineInfo_Serial.RegSerial(SoftName);
               RegistryTool.RegistrySave(AuthorName + Decodex107(25) + SoftName + Decodex107(26), Decodex107(27), serial);
                MessageBox.Show(Decodex107(60));
            }
        }
    }
}

